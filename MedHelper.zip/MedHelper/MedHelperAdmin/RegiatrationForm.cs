﻿using MedHelperLibrary.DAL;
using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class RegiatrationForm : Form
    {
        UsersLoader UserData;
        public RegiatrationForm()
        {
            InitializeComponent();
            UserData = new UsersLoader();
            UserData.LoadError += ErrorHandler;
            UserData.Load();
        }

        public void ErrorHandler(string message)
        {
            MessageBox.Show("You must fix mistakes in account.txt before adding new profile\n" + message, 
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Close();
        }

        public bool Validation(string login, string pass1, string pass2, string access)
        {
            // login validation            
            if (login.Length < 4) 
            {
                ValidationError("Login must be at least 4 characters");
                return false;
            }

            // Serch for dublicates
            foreach (User us in UserData.users)
            {
                if (login == us.Login)
                {
                    ValidationError("This login is already taken");
                    return false;
                }
            }

            // passwords validation
            if (pass1 != pass2)
            {
                ValidationError("Passwords do not match");
                return false;
            }
            if (pass1.Length < 4) 
            {
                ValidationError("Password must be at least 4 characters");
                return false;
            }

            if (access == "")
            {
                ValidationError("You haven't chosen the access value");
                return false;
            }

            return true; 
        }

        public void ValidationError(string message) 
        {
            labelMessage.Text = message;
            labelMessage.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            string password1 = textBox2.Text;
            string password2 = textBox3.Text;
            string access = comboBox1.Text;

            //Проверяем данные и добавляем пользователя
            if (Validation(login, password1, password2, access))
            {
                if (access == "Admin")
                    UserData.users.Add(new Admin(login, password1, access));
                else
                    UserData.users.Add(new Doctor(login, password1, access));
                UserData.Save();
                MessageBox.Show("New profile has been added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Очищаем поля
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.SelectedItem = null;
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char symbol = e.KeyChar;
            if (!Char.IsLetter(symbol) && !Char.IsControl(symbol) && !Char.IsDigit(symbol)) 
            {
                e.Handled = true;
                ValidationError($"Character {symbol} is not allowed in the login field ");
            }
        }
    }
}
