﻿using MedHelperLibrary.DAL;
using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class AdminAppForm : Form
    {
        Hospital hospital;
        BindingSource dataBinder = new BindingSource();

        public AdminAppForm() 
        {
            hospital = new Hospital();
            InitializeComponent();
            hospital.Load();
            dataGridView1.DataSource = dataBinder;
            MedecineDisplay();

            comboBoxMode.SelectedIndex = 0;
            label1.Text = Convert.ToString(hospital.Medicines[0].Name);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // проверяем что это ячейка из списка лекарств
            if (dataGridView1.SelectedCells[0].ColumnIndex == dataGridView1.Columns["Name"].Index && dataGridView1.SelectedCells[0].RowIndex != -1) 
            {
                MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[dataGridView1.SelectedCells[0].RowIndex],true);

                //Создаем форму и проверяем на сохранение данных
                if ((EditForm.ShowDialog()) == DialogResult.OK)
                    dataBinder.ResetBindings(false);
            }
            else
            {
                MessageBox.Show("Please, choose a sell to edit", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void addAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegiatrationForm RegForm = new RegiatrationForm();
            try
            {
                RegForm.ShowDialog();
            }
            catch { }
        }

        private void dataGridView1_SizeChanged(object sender, EventArgs e)
        {
            dataGridView1.Columns["Name"].Width = dataGridView1.Width / 2;
            dataGridView1.Columns["Amount"].Width = dataGridView1.Width / 2;
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            label1.Text = hospital.Medicines[e.RowIndex].Amount.ToString();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (comboBoxMode.SelectedIndex == 0)  // Активировано окно медикаментов
            {
                if (e.ColumnIndex == dataGridView1.Columns["Name"].Index && e.RowIndex != -1) // проверяем что это ячейка из списка лекарств
                {
                    MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[e.RowIndex],true);

                    //Создаем форму и проверяем на сохранение данных
                    if ((EditForm.ShowDialog()) == DialogResult.OK)
                        dataBinder.ResetBindings(false);
                }
            }
            else // Окно поставок
            {
                // Просмотр поставки
            } 
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Создаем пустое лекарство и передаем в форму
            Medicine temp = new Medicine("", "", "", 0, null);
            MedicineEditForm EditForm = new MedicineEditForm(temp,true);

            // В случае сохранения добавляем в список
            if ((EditForm.ShowDialog()) == DialogResult.OK)
            {
                hospital.Medicines.Add(temp);
                dataBinder.ResetBindings(false);
            }
        }

        private void comboBoxMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxMode.SelectedIndex == 0)
                MedecineDisplay();
            else
                SupplyDisplay();
        }      

        private void MedecineDisplay() 
        {
            dataBinder.DataSource = hospital.Medicines;
            dataGridView1.Columns["Name"].ReadOnly = true;
            dataGridView1.Columns["Id"].Visible = false;
            dataGridView1.Columns["Description"].Visible = false;
            dataGridView1.Columns["Unit"].Visible = false;


            //Визуальная часть
            dataGridView1.Columns["Name"].Width = dataGridView1.Width / 2;
            dataGridView1.Columns["Amount"].Width = dataGridView1.Width / 2;
        }

        private void SupplyDisplay() 
        {
            dataBinder.DataSource = hospital.Supplies;
            dataGridView1.Columns["Id"].Visible = false;
            dataGridView1.Columns["DateTime"].Width = dataGridView1.Width;

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SupplyCreator SupplyForm = new SupplyCreator(hospital);
            SupplyForm.ShowDialog();
            dataBinder.ResetBindings(false);
        }
    }
}
