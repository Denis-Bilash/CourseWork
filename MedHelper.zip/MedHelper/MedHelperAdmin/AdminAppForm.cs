﻿using MedHelperLibraryNew.DAL;
using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class AdminAppForm : Form
    {
        Hospital hospital;
        AutoCompleteStringCollection AutoCompleteMedicine;
        AutoCompleteStringCollection AutoCompleteSupply;
        bool IsDirty;
        public AdminAppForm() 
        {
            hospital = new Hospital();
            InitializeComponent();
            hospital.Load();
            IsDirty = false;

            dataGridView1.DataSource = medicineBindingSource;
            medicineBindingSource.DataSource = hospital.Medicines;

            dataGridView2.DataSource = supplyBindingSource;
            supplyBindingSource.DataSource = hospital.Supplies;

            AutoCompliteMedicineCorrection();
            AutoCompleteSupplyCorrection();


        }

        public void AutoCompliteMedicineCorrection()          // Поиск лекарств
        {
            AutoCompleteMedicine = new AutoCompleteStringCollection();
            for (int i = 0; i < hospital.Medicines.Count; i++)
                AutoCompleteMedicine.Add(hospital.Medicines[i].Name);

            textBoxSearchMedicine.AutoCompleteCustomSource = AutoCompleteMedicine;
            textBoxSearchMedicine.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBoxSearchMedicine.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        public void AutoCompleteSupplyCorrection()          // Поиск лекарств
        {
            AutoCompleteSupply = new AutoCompleteStringCollection();
            for (int i = 0; i < hospital.Supplies.Count; i++)
                AutoCompleteSupply.Add(Convert.ToString(hospital.Supplies[i].DateTime));

            textBoxSearchSupply.AutoCompleteCustomSource = AutoCompleteSupply;
            textBoxSearchSupply.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBoxSearchSupply.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }



        private void addAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegiatrationForm RegForm = new RegiatrationForm();
            try
            {
                RegForm.ShowDialog();
            }
            catch { }
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // Активировано окно медикаментов          
            if (e.ColumnIndex >= 0 && e.ColumnIndex <= 1  && e.RowIndex != -1) // проверяем что это ячейка из списка лекарств
            {
                MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[e.RowIndex], hospital);

                //Создаем форму и проверяем на сохранение данных
                if ((EditForm.ShowDialog()) == DialogResult.OK)
                {
                    medicineBindingSource.ResetBindings(false);
                    AutoCompliteMedicineCorrection();
                    IsDirty = true;
                }
            }
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddMedicine();
        }

        

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSupply();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
                buttonEdit.Text = "Edit";
            else
                buttonEdit.Text = "Open";
        }

        private void buttonSearchMedicine_Click(object sender, EventArgs e)
        {
            int index = AutoCompleteMedicine.IndexOf(textBoxSearchMedicine.Text);
            if (index != -1)
            {
                dataGridView1.Rows[index].Cells[0].Selected = true;
            }
            else 
            {
                MessageBox.Show("Not found", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonSearchSupply_Click(object sender, EventArgs e)
        {
            int index = AutoCompleteSupply.IndexOf(textBoxSearchSupply.Text);
            if (index != -1)
            {
                dataGridView2.Rows[index].Cells[0].Selected = true;
            }
            else
            {
                MessageBox.Show("Not found", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                AddMedicine();
            }
            else if (tabControl1.SelectedIndex == 1)
            {//Supply
                AddSupply();
            }
            else
                MessageBox.Show("Adding error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                EditMedicine();
            }
            else if (tabControl1.SelectedIndex == 1)
            {//Supply
                OpenSupply();
            }
            else
                MessageBox.Show("Edition error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }

        public void OpenSupply() 
        {
            if (dataGridView2.SelectedCells[0].RowIndex != -1)
            {
                SupplyViewer SupplyViewer = new SupplyViewer(hospital.Supplies[dataGridView2.SelectedCells[0].RowIndex]);
                SupplyViewer.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please, choose a supply to open", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tabControl1.SelectedIndex = 1;
            }
        }

        public void AddMedicine()
        {
            // Создаем пустое лекарство и передаем в форму
            MedicineEditForm EditForm = new MedicineEditForm(hospital);

            // В случае сохранения добавляем в список
            if ((EditForm.ShowDialog()) == DialogResult.OK)
            {
                medicineBindingSource.ResetBindings(false);
                AutoCompliteMedicineCorrection();
                IsDirty = true;
            }
        }

        public void AddSupply() 
        {
            int count = hospital.Medicines.Count;
            AddSupply AddSupplyForm = new AddSupply(hospital);
            if (AddSupplyForm.ShowDialog() == DialogResult.Yes)
            {
                supplyBindingSource.ResetBindings(true);           
                medicineBindingSource.ResetBindings(true);
                IsDirty = true;
            }
        }

        public void EditMedicine() 
        {
            // проверяем что это ячейка из списка лекарств
            if (dataGridView1.SelectedCells[0].RowIndex != -1 && tabControl1.SelectedIndex == 0)
            {
                MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[dataGridView1.SelectedCells[0].RowIndex], hospital);
                //Создаем форму и проверяем на сохранение данных
                if ((EditForm.ShowDialog()) == DialogResult.OK)
                {
                    medicineBindingSource.ResetBindings(false);
                    AutoCompliteMedicineCorrection();
                    IsDirty = true;
                }
            }
            else
            {
                MessageBox.Show("Please, choose a medicine to edit", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tabControl1.SelectedIndex = 0;
            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditMedicine();
        }

        private void addToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                MessageBox.Show("Please, choose a supply to open", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tabControl1.SelectedIndex = 1;
            }
            else
                OpenSupply();
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            OpenSupply();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (DeleteMedicine())
            {
                medicineBindingSource.ResetBindings(false);
                IsDirty = true;
            }

        }

        public bool DeleteMedicine() 
        {
            int index = dataGridView1.SelectedCells[0].RowIndex;
            if (index != -1 && tabControl1.SelectedIndex <= 0)
            {
                if (hospital.Medicines[dataGridView1.SelectedCells[0].RowIndex].Amount == 0)
                {
                    var rez = MessageBox.Show($"Are you sure you want to delete medicine" +
                        $" {hospital.Medicines[index].Name}?",
                        "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (rez == DialogResult.Yes)
                    {
                        hospital.Medicines.RemoveAt(index);
                        MessageBox.Show($"Complited", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return true;
                    }
                }
                else
                {
                    MessageBox.Show($"You can not delete medicine, if it's amount is greater than 0", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }
            }
            else
            {
                MessageBox.Show("Choose a medicine to delete", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                tabControl1.SelectedIndex = 0;
                return false;
            }
            return false;
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hospital.Save();
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            hospital.Load();
            MessageBox.Show("Load complited", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AdminAppForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (IsDirty) 
            {
               var rez =  MessageBox.Show("Tou have some unsaved data. Do you want to save it?", "Warning",
                   MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    hospital.Save();
                else if (rez == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void dataGridView1_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            IsDirty = true;
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Administrator menu help\n\n" +
                "This is the main window for adminstrator.Threre are two main sections: for medecines and for supplies,\n" +
                " vere you can edit them" +
                " or view their information.\n " +
                "Here you can do several things:\n     " +
                "1. In \"File\" menu you can save and load the program's data. You also can close the program by clicking \"Exit\" button\n     " +
                "2. You can create a new user account by clicking at \"Account -> Add\" button in the upper menu\n     " +
                "3. At the \"Medicines\" section you can add, edit and delete medicines by cliching at corresponding buttons\n     " +
                "4. At the \"Supplies\" menu you can add and open supplies by cliching at corresponding buttons\n     " +
                "You can also use the uppermenu buttons for such purposes\n";
            AdminHelp AdminHelp = new AdminHelp(message);
            AdminHelp.ShowDialog();
        }
    }
}
