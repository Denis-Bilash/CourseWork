﻿using MedHelperLibraryNew.DAL;
using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class AdminAppForm : Form
    {
        Hospital hospital;

        public AdminAppForm() 
        {
            hospital = new Hospital();
            InitializeComponent();
            hospital.AddTestData(100);
            hospital.Save();
            //hospital.Load();
            dataGridView1.DataSource = medicineBindingSource;
            
            MedecineDisplay();

            comboBoxMode.SelectedIndex = 0;
            label1.Text = Convert.ToString(hospital.Medicines[0].Name);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // проверяем что это ячейка из списка лекарств
            if (dataGridView1.SelectedCells[0].RowIndex != -1) 
            {
                MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[dataGridView1.SelectedCells[0].RowIndex],hospital,true);

                //Создаем форму и проверяем на сохранение данных
                if ((EditForm.ShowDialog()) == DialogResult.OK)
                    medicineBindingSource.ResetBindings(false);
            }
            else
            {
                MessageBox.Show("Please, choose a sell to edit", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void addAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RegiatrationForm RegForm = new RegiatrationForm();
            try
            {
                RegForm.ShowDialog();
            }
            catch { }
        }

        private void dataGridView1_SizeChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            label1.Text = hospital.Medicines[e.RowIndex].Amount.ToString();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (comboBoxMode.SelectedIndex == 0)  // Активировано окно медикаментов
            {
                if (e.ColumnIndex == 1 && e.RowIndex != -1) // проверяем что это ячейка из списка лекарств
                {
                    MedicineEditForm EditForm = new MedicineEditForm(hospital.Medicines[e.RowIndex],hospital,true);

                    //Создаем форму и проверяем на сохранение данных
                    if ((EditForm.ShowDialog()) == DialogResult.OK)
                        medicineBindingSource.ResetBindings(false);
                }
            }
            else // Окно поставок
            {
                // Просмотр поставки
            } 
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Создаем пустое лекарство и передаем в форму
            Medicine temp = new Medicine("", "", "", 0, null,null);
            MedicineEditForm EditForm = new MedicineEditForm(temp,hospital,true);

            // В случае сохранения добавляем в список
            if ((EditForm.ShowDialog()) == DialogResult.OK)
            {
                hospital.Medicines.Add(temp);
                medicineBindingSource.ResetBindings(false);
            }
        }

        private void comboBoxMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxMode.SelectedIndex == 0)
                MedecineDisplay();
            else
                SupplyDisplay();
        }      

        private void MedecineDisplay() 
        {
            medicineBindingSource.DataSource = hospital.Medicines;
        }

        private void SupplyDisplay() 
        {
            medicineBindingSource.DataSource = hospital.Supplies;

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SupplyCreator SupplyForm = new SupplyCreator(hospital);
            SupplyForm.ShowDialog();
            medicineBindingSource.ResetBindings(false);
        }
    }
}
