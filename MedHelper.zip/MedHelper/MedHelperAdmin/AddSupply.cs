﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class AddSupply : Form
    {
        Hospital hospital;
        public AddSupply(Hospital sended)
        {
            InitializeComponent();
            hospital = sended;
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            List<Portion> portions = new List<Portion>();
            //ПРОВЕВКА ВВЕДЕННЫХ ЗНАЧЕНИЙ
            List<string> names = new List<string>();
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                //Проверка на правильность ввода
                string name = (string)dataGridView1.Rows[i].Cells[0].Value;
                string amount = (string)dataGridView1.Rows[i].Cells[1].Value;
                if (name == null || amount == null) 
                {
                    MessageBox.Show($"Empty value at line #{i}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[i].Selected = true;
                    dataGridView1.Columns[1].Selected = true;
                    buttonSave.DialogResult = DialogResult.None;
                    return;
                }
                name = name.Trim(' ');
                amount = amount.TrimStart('0');
                amount = amount.Trim(' ');
                
                if (ValidateSupplyName(name, i) == false || ValidateSupplyAmount(amount,i) == false)
                { // Имя или количество в строке невалидно
                    buttonSave.DialogResult = DialogResult.None;
                    return;
                }

                //Проверка на соответствие с медикаментом
                int index = hospital.Medicines.FindIndex((x) => x.Name.ToUpper() == name.ToUpper());
                if (index != -1)
                {// Лекарство существует
                    portions.Add(new Portion(hospital.Medicines[index], Convert.ToInt32(amount)));//Копируем лекарство с описаннием в этот момент времени 
                }
                else 
                {// Лекарство имеет валидное имя, но его нет в медикаментах
                 // Предлагаем его добавить
                    var rez = MessageBox.Show($"Medicine {name} in not in the base. Do you want to add it?","Warning",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (rez == DialogResult.Yes)
                    {
                        MedicineEditForm MedicineEditForm = new MedicineEditForm(hospital, name, Convert.ToInt32(amount));
                        if (MedicineEditForm.ShowDialog() == DialogResult.OK) 
                        {
                            // ********** Проверяем было си добавленно лекарство(по идеи добавляеться в конец списка, но мало ли)
                            index = hospital.Medicines.FindIndex((x) => x.Name.ToUpper() == name.ToUpper());                          
                            if (index != -1) 
                            {// После добавления лекарство было найдено
                                portions.Add(new Portion(hospital.Medicines[index], Convert.ToInt32(amount)));//Копируем лекарство с описаннием в этот момент времени 
                            }
                            else {
                                MessageBox.Show($"Unknown error. Medicine {name} hasn't beed added to the base.", "Warning",
                                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                buttonSave.DialogResult = DialogResult.None;
                                return;
                            }
                            // ***********
                        }
                        else
                        // Пользователь не добавил лекарство во время процедуры лобавления
                        {
                            MessageBox.Show($"You can not add medicine {name} until it is not in the base", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                            buttonSave.DialogResult = DialogResult.None;
                            return;
                        }
                    }
                    else 
                    {
                        MessageBox.Show($"You can not add medicine {name} until it is not in the base", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                        buttonSave.DialogResult = DialogResult.None;
                        return;
                    }
                }
            }
            if (dataGridView1.Rows.Count == 1) 
            {
                MessageBox.Show($"There is nothing to save yet", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                buttonSave.DialogResult = DialogResult.None;
                return;
            }
            //На этом этапе есть список порций, то есть поставка. Осталось обновить данные 

            for (int j = 0; j < portions.Count; j++) 
            {
                int index = hospital.Medicines.FindIndex((x) => x.Name == portions[j].Medicine.Name);
                if (index != -1) 
                {
                    hospital.Medicines[index].Amount += (int)portions[j].Amount;
                }
                else
                {
                    MessageBox.Show($"SystemError. Invalid portions list", "Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                    buttonSave.DialogResult = DialogResult.None;
                    return;
                }
            }
            hospital.Supplies.Add(new Supply(portions));
            MessageBox.Show($"Supply has been saved", "Success!",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public bool ValidateSupplyAmount(string amount, int rowindex) 
        {
            if (amount == "")
            {
                MessageBox.Show($"Empty value at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[rowindex].Selected = true;
                dataGridView1.Columns[1].Selected = true;
                return false;
            }
            foreach (char c in amount)
            {
                if (!Char.IsDigit(c))
                {
                    MessageBox.Show($"Invalid medicine amount at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[rowindex].Selected = true;
                    dataGridView1.Columns[1].Selected = true;
                    return false;
                }
            }
            return true;
        }

        public bool ValidateSupplyName(string name, int rowindex) 
        {
            if (name == "")
            {
                MessageBox.Show($"Empty value at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[rowindex].Selected = true;
                dataGridView1.Columns[0].Selected = true;
                return false;
            }
            foreach (char c in name)
            {
                if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))
                {
                    MessageBox.Show($"Invalid medicine name at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[rowindex].Selected = true;
                    dataGridView1.Columns[0].Selected = true;
                    return false;
                }
            }
            return true;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void AddSupply_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (buttonSave.DialogResult == DialogResult.None)
            {
                buttonSave.DialogResult = DialogResult.Yes;
                e.Cancel = true;
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(new DataGridViewRow());
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.IsNewRow == false) // Не пустая строка
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
        }
    }
}
