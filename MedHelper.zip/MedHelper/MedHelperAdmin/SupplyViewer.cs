﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class SupplyViewer : Form
    {
        Supply supply;
        public SupplyViewer(Supply sended)
        {
            InitializeComponent();
            supply = sended;
            portionBindingSource.DataSource = supply.Portions;
        }

        private void SupplyViewer_Load(object sender, EventArgs e)
        {
            label2.Text = Convert.ToString(supply.Id);
            label4.Text = Convert.ToString(supply.DateTime);
        }
    }
}
