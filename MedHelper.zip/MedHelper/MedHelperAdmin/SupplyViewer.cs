﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class SupplyViewer : Form
    {
        Supply Supply { get; }
        public SupplyViewer(Supply sended)
        {
            InitializeComponent();
            Supply = sended;
            portionBindingSource.DataSource = Supply.Portions;
        }

        private void SupplyViewer_Load(object sender, EventArgs e)
        {
            label2.Text = Convert.ToString(Supply.Id);
            label4.Text = Convert.ToString(Supply.DateTime);
        }

        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MedicineEditForm MedicineEditForm = new MedicineEditForm(Supply.Portions[e.RowIndex].Medicine);
            MedicineEditForm.ShowDialog();
        }
    }
}
