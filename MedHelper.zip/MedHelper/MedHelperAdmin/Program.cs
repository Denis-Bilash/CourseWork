﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            ////Запускаем LogInSystem
            string AdminAppPath = @"\LogInSystem\bin\Debug\LogInSystem.exe";
            try // В слечае перемещения файла, запуститься но без системы входа
            {
                string path = new DirectoryInfo(@"..\..\..").FullName + AdminAppPath;
                Process.Start(path);
            }
            catch 
            {
                Application.Run(new AdminAppForm());
            }
                
        }
    }
}
