﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class SupplyCreator : Form
    {
        Hospital SupplyHospital;
        BindingSource supplyBinder = new BindingSource();

        List<ComboBox> Boxes = new List<ComboBox>();
        List<NumericUpDown> UpDowns = new List<NumericUpDown>();
        int pos= 0;
        bool canAdd = true;

        public SupplyCreator(Hospital sended)
        {
            InitializeComponent();
            SupplyHospital = sended;
            supplyBinder.DataSource = SupplyHospital.Medicines;

            //AddField();
        }

        public void AddField() 
        {
            if (canAdd) 
            {
                pos += 50;

                //ComboBox                
                ComboBox currBox = new ComboBox();
                currBox.Left = 0;
                currBox.Top = pos;
                currBox.Height = 50;
                currBox.Width = panel1.Width /2;
                currBox.Items.AddRange(SupplyHospital.Medicines.ToArray());
                currBox.DisplayMember = "Medicine";                   // Тут отображаеться Medicine.ToString()
                currBox.TextUpdate += CheckField;
                currBox.SelectedIndexChanged += CheckField;
                panel1.Controls.Add(currBox);
                Boxes.Add(currBox);
                currBox.Text = "";
                //ComboBox

                //UpDown                
                NumericUpDown currUpDown = new NumericUpDown();
                currUpDown.Left = currBox.Left + currBox.Width;
                currUpDown.Top = pos;
                currUpDown.Height = 50;
                currUpDown.Width = (panel1.Width / 2) - 50;
                //Задаем события для проверки изменения
                currUpDown.KeyUp += CheckField;
                currUpDown.MouseWheel += CheckField;
                currUpDown.MouseUp += CheckField;
                panel1.Controls.Add(currUpDown);
                UpDowns.Add(currUpDown);
                //UpDown    
            }
        }

        public void CheckField(object sender, EventArgs e) 
        {
            ComboBox button = (ComboBox)panel1.Controls[panel1.Controls.Count-2];
            NumericUpDown updown = (NumericUpDown)panel1.Controls[panel1.Controls.Count-1];
            if (button.Text != "" && updown.Value > 0)
                AddField();
        }

        public void SaveSupply() 
        {
            List<Portion> portions = new List<Portion>();
            List<Medicine> Candidates = new List<Medicine>();  // список перпаратов, которые нужно изменить

            for(int i = 0; i < Boxes.Count-1; i++)
            {
                ComboBox box = Boxes[i];
                int boxValue = (int)UpDowns[i].Value;
                bool exist = false;                  

                foreach (Medicine medecine in SupplyHospital.Medicines)    // Проверяем существует ли такое лекарство
                {
                    if (medecine.Name == box.Text) 
                    {
                        if (boxValue > 0)
                        {
                            exist = true;
                            Candidates.Add(medecine);
                            break;
                        }
                    }
                }

                // Предлагаем добавить лекарство если его нет в базе или его Amount равен 0
                if (exist == false) 
                {
                    if (boxValue == 0) 
                    {
                        MessageBox.Show($"Amount of {box.Text} equals to 0 .",
                                       "Warning",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Warning);
                        return;
                    }

                    box.Focus();
                    DialogResult rez = MessageBox.Show($"Medecine {box.Text} is not in the base. Do you want to add it?", 
                                    "Warning", 
                                    MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Warning);
                    // Вызываем форму для добавления медикамента
                    if (rez == DialogResult.Yes)
                    {
                        Medicine temp = new Medicine(box.Text, "", "", 0, null,null);
                        MedicineEditForm EditForm = new MedicineEditForm(temp,SupplyHospital,false);
                        if ((EditForm.ShowDialog()) == DialogResult.OK)
                        {
                            SupplyHospital.Medicines.Add(temp);
                            Candidates.Add(temp);
                        }
                    }
                    else // в противном случае завершаем процесс сохранения поставки
                    {
                        MessageBox.Show($"You can not save the supply unlit it contains unknown medecines",
                                       "Warning",
                                       MessageBoxButtons.OK,
                                       MessageBoxIcon.Error);
                        return;
                    }
                }
            }

            // Сам процесс обновления Amount
            for (int j = 0; j < Boxes.Count - 1; j++)
            {
                int boxValue = (int)UpDowns[j].Value;
                Candidates[j].ChangeAmmount(boxValue);
                portions.Add(new Portion(Candidates[j], boxValue));
            }

            //Валидация пройденна, сохраняем поставку
            SupplyHospital.Supplies.Add(new Supply(portions));

        }

        private void SupplyCreator_Load(object sender, EventArgs e)
        {
            AddField();
        }

        private void button1_Click_1(object sender, EventArgs e)         // Показывает пользователю где находяться неправильно заполненные поля
        {
            for (int i = 0; i < Boxes.Count; i++) 
            {
                if (Boxes[i].Text == "")
                {
                    MessageBox.Show($"Empty name field",
               "Warning",
               MessageBoxButtons.OK,
               MessageBoxIcon.Warning);
                    Boxes[i].Focus();
                    return;
                }
                if (UpDowns[i].Value == 0) 
                {
                    MessageBox.Show($"Zero value field",
               "Warning",
               MessageBoxButtons.OK,
               MessageBoxIcon.Warning);
                    UpDowns[i].Focus();
                    return;
                }
            }
        }

        private void SupplyCreator_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSupply();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
