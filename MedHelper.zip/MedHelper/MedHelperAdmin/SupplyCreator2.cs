﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class SupplyCreator2 : Form
    {
        Hospital SupplyHospital;

        public SupplyCreator2(Hospital sended)
        {
            InitializeComponent();
            SupplyHospital = sended;
        }

        private void SupplyCreator2_Load(object sender, EventArgs e)
        {
        }
    }
}
