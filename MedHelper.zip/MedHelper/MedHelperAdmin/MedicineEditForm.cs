﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class MedicineEditForm : Form
    {
        Medicine currMedicine;
        Hospital Hospital { get; }
        string id;
        public MedicineEditForm(Hospital secondsended)  // Конструктор для Add
        {
            InitializeComponent();
            Hospital = secondsended;

        }

        public MedicineEditForm(Medicine sended, Hospital secondsended)  // Конструктор для Edit
        {
            InitializeComponent();
            Hospital = secondsended;
            currMedicine = sended;
        }
        public MedicineEditForm(Hospital secondsended, string MedicineName, int MedicineAmount)  // Конструктор для AddSupply
        {
            InitializeComponent();
            Hospital = secondsended;
            textBoxAmount.Text = Convert.ToString(MedicineAmount);
            textBoxName.Text = MedicineName;
            textBoxAmount.Enabled = false;
            textBoxName.Enabled = false;
        }

        public MedicineEditForm(Medicine sended)  // Конструктор для OpenSupply
        {
            InitializeComponent();
            currMedicine = sended;
            textBoxName.ReadOnly = true;
            textBoxDescription.ReadOnly = true;
            textBoxId.ReadOnly = true;
            textBoxAmount.ReadOnly = true;
            textBoxUnit.ReadOnly = true;
            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            dataGridView1.ReadOnly = true;
        }

        private void MedicineEditForm_Load(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files(*.BMP; *.JPG; *.PNG; *.JPEG)| *.BMP; *.JPG; *.PNG; *.JPEG | All files(*.*) | *.*";
            
            if (currMedicine == null)
            {
                id = Guid.NewGuid().ToString();
                textBoxId.Text = id; // Ожидаемый Id
                pictureBox1.Image = new Bitmap(new DirectoryInfo(@"..\..\..").FullName + @"\Images\Default.jpg");
            }
            else 
            {
                textBoxName.Text = currMedicine.Name;
                textBoxDescription.Text = currMedicine.Description;
                textBoxId.Text = Convert.ToString(currMedicine.Id);
                textBoxAmount.Text = Convert.ToString(currMedicine.Amount);
                textBoxUnit.Text = currMedicine.Unit;
                pictureBox1.Image = currMedicine.Image;

                for (int i = 0; i < currMedicine.Replacements.Count; i++) 
                {
                    dataGridView1.Rows.Add(new DataGridViewRow());
                    dataGridView1.Rows[i].Cells[0].Value = currMedicine.Replacements[i];
                }
            }
        }

        public void ShowWarning(string message) 
        {
            MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            DialogResult = DialogResult.None; 
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "") 
            { ShowWarning("Invalid name"); return; }
            if(textBoxName.Text.Trim(' ') != textBoxName.Text)
            { var rez = MessageBox.Show("Invalid wightspaces at the name field. Do you want to delete them?", "Warning", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    textBoxName.Text = textBoxName.Text.Trim(' ');
                else
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }
            if (textBoxUnit.Text == "")
            { ShowWarning("Invalid unit "); return; }
            if (textBoxAmount.Text == "" || (textBoxAmount.Text.Length >1 && textBoxAmount.Text[0] == '0'))
            { ShowWarning("Invalid amount"); return; }
            if (Hospital.FindMedicieIndex(textBoxName.Text.ToLower()) != -1)
            {
                if (currMedicine == null || textBoxName.Text != currMedicine.Name)
                {
                    ShowWarning("Medicine with this name already exists");
                    return;
                }
            }

            //Валидация заменителей
            List<string> replacements = new List<string>();
            for (int i = 0; i < dataGridView1.Rows.Count-1; i++) 
            {
                string s = (string)dataGridView1.Rows[i].Cells[0].Value;
                if (s == null)
                {
                    ShowWarning($"Empty value at line #{i}");
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[i].Selected = true;
                    return;
                }

                s = s.Trim(' ');
                if (s == "") 
                {
                    ShowWarning($"Empty value at line #{i}");
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[i].Selected = true;
                    return;
                }

                foreach (char c in s) 
                {
                    if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))                    
                    {
                        ShowWarning($"Invalid replecement name at line #{i}");
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[i].Selected = true;
                        return;
                    }    
                }
                replacements.Add(s);
            }

            // Сохраняем данные (без привязки)
            if (currMedicine == null) 
            {
                currMedicine = new Medicine(textBoxName.Text, textBoxDescription.Text, textBoxUnit.Text, 
                    Convert.ToInt32(textBoxAmount.Text),replacements,pictureBox1.Image,id);
                Hospital.Medicines.Add(currMedicine);
            }
            else
            {
                currMedicine.Name = textBoxName.Text;
                currMedicine.Description = textBoxDescription.Text;
                currMedicine.Unit = textBoxUnit.Text;
                currMedicine.Amount = Convert.ToInt32(textBoxAmount.Text);
                currMedicine.Replacements.Clear();
                currMedicine.Replacements.AddRange(replacements);
                currMedicine.Image = pictureBox1.Image;
            }


        }

        private void TextBoxAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
                
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(new DataGridViewRow());
        }

        private void TextBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar) && !Char.IsControl(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void TextBoxUnit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow.IsNewRow == false) // Не пустая строка
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
        }

        private void TextBoxDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                Image image = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = new Bitmap(image,100,100);
            }
        }

    }
}
