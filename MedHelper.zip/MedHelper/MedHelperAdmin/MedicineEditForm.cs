﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class MedicineEditForm : Form
    {
        Medicine currMedicine;
        Hospital hospital;
        public MedicineEditForm(Medicine sended, Hospital secondsended, bool AmountAllowed)  // Конструктор для Edit
        {
            InitializeComponent();
            currMedicine = sended;
            hospital = secondsended;
            if (!AmountAllowed)     // Если открываеться при добавлении поставки. Количество добовляем после успешной поставки
            {
                currMedicine.Amount = 0;
                textBoxAmount.Visible = false;
                label4.Visible = false;
            }

        }

        private void MedicineEditForm_Load(object sender, EventArgs e)
        {
            // Привязку не делаем так как неизвестно нужно ли сохранить изменения
            // Сообщаем исходные значения
            textBoxName.Text = currMedicine.Name;
            textBoxDescription.Text = currMedicine.Description;
            label5.Text = Convert.ToString(currMedicine.Id);
            textBoxAmount.Text = Convert.ToString(currMedicine.Amount);
            textBoxUnit.Text = currMedicine.Unit;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "") 
            { MessageBox.Show("Invalid name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxUnit.Text == "")
            { MessageBox.Show("Invalid unit ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxAmount.Text == "" || (textBoxAmount.Text.Length >1 && textBoxAmount.Text[0] == '0'))
            { MessageBox.Show("Invalid amount", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            for (int i = 0; i < hospital.Medicines.Count; i++) 
            {
                if (textBoxName.Text != currMedicine.Name && hospital.Medicines.FindIndex((x)=> x.Name == textBoxName.Text) != -1)
                {
                    MessageBox.Show("Medicine with this name already exists", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            // Сохраняем данные (без привязки)
            currMedicine.Name = textBoxName.Text;
            currMedicine.Description = textBoxDescription.Text;
            currMedicine.Unit = textBoxUnit.Text;
            currMedicine.Amount = Convert.ToInt32(textBoxAmount.Text);

        }

        private void MedicineEditForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void textBoxAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
                
        }
    }
}
