﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperAdmin
{
    public partial class MedicineEditForm : Form
    {
        Medicine currMedicine;
        Hospital hospital;
        public MedicineEditForm(Hospital secondsended)  // Конструктор для Add
        {
            InitializeComponent();
            hospital = secondsended;

        }

        public MedicineEditForm(Medicine sended, Hospital secondsended)  // Конструктор для Edit
        {
            InitializeComponent();
            hospital = secondsended;
            currMedicine = sended;
        }
        public MedicineEditForm(Hospital secondsended, string MedicineName, int MedicineAmount)  // Конструктор для AddSupply
        {
            InitializeComponent();
            hospital = secondsended;
            textBoxAmount.Text = Convert.ToString(MedicineAmount);
            textBoxName.Text = MedicineName;
            textBoxAmount.Enabled = false;
            textBoxName.Enabled = false;
        }

        private void MedicineEditForm_Load(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files(*.BMP; *.JPG; *.PNG; *.JPEG)| *.BMP; *.JPG; *.PNG; *.JPEG | All files(*.*) | *.*";
            
            if (currMedicine == null)
            {
                labelId.Text = Convert.ToString(hospital.Medicines[hospital.Medicines.Count - 1].Id + 1); // Ожидаемый Id
                pictureBox1.Image = new Bitmap(new DirectoryInfo(@"..\..\..").FullName + @"\Images\Default.jpg");
            }
            else 
            {
                textBoxName.Text = currMedicine.Name;
                textBoxDescription.Text = currMedicine.Description;
                labelId.Text = Convert.ToString(currMedicine.Id);
                textBoxAmount.Text = Convert.ToString(currMedicine.Amount);
                textBoxUnit.Text = currMedicine.Unit;
                pictureBox1.Image = currMedicine.Image;

                for (int i = 0; i < currMedicine.Replacements.Count; i++) 
                {
                    dataGridView1.Rows.Add(new DataGridViewRow());
                    dataGridView1.Rows[i].Cells[0].Value = currMedicine.Replacements[i];
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "") 
            { MessageBox.Show("Invalid name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if(textBoxName.Text.Trim(' ') != textBoxName.Text)
            { var rez = MessageBox.Show("Invalid wightspaces at the name field. Do you want to delete them?", "Warning", MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    textBoxName.Text = textBoxName.Text.Trim(' ');
                else
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }
            if (textBoxUnit.Text == "")
            { MessageBox.Show("Invalid unit ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxAmount.Text == "" || (textBoxAmount.Text.Length >1 && textBoxAmount.Text[0] == '0'))
            { MessageBox.Show("Invalid amount", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (hospital.Medicines.FindIndex((x)=> x.Name.ToLower() == textBoxName.Text.ToLower()) != -1)
            {
                if (currMedicine == null || textBoxName.Text != currMedicine.Name)
                {
                    MessageBox.Show("Medicine with this name already exists", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            //Валидация заменителей
            List<string> replacements = new List<string>();
            for (int i = 0; i < dataGridView1.Rows.Count-1; i++) 
            {
                string s = (string)dataGridView1.Rows[i].Cells[0].Value;
                s = s.Trim(' ');
                if (s == null)
                {
                    MessageBox.Show($"Empty value at line #{i}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[i].Selected = true;
                    DialogResult = DialogResult.None;
                    return;
                }
                foreach (char c in s) 
                {
                    if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))                    
                    {
                        MessageBox.Show($"Invalid replecement name at line #{i}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        dataGridView1.ClearSelection();
                        dataGridView1.Rows[i].Selected = true;
                        DialogResult = DialogResult.None;
                        return;
                    }    
                }
                replacements.Add(s);
            }

            // Сохраняем данные (без привязки)
            if (currMedicine == null) 
            {
                currMedicine = new Medicine(textBoxName.Text, textBoxDescription.Text, textBoxUnit.Text, 
                    Convert.ToInt32(textBoxAmount.Text),replacements,pictureBox1.Image);
                hospital.Medicines.Add(currMedicine);
            }
            else
            {
                currMedicine.Name = textBoxName.Text;
                currMedicine.Description = textBoxDescription.Text;
                currMedicine.Unit = textBoxUnit.Text;
                currMedicine.Amount = Convert.ToInt32(textBoxAmount.Text);
                currMedicine.Replacements.Clear();
                currMedicine.Replacements.AddRange(replacements);
                currMedicine.Image = pictureBox1.Image;
            }


        }

        private void MedicineEditForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void textBoxAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
                
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(new DataGridViewRow());
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar) && !Char.IsControl(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void textBoxUnit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentRow.IsNewRow == false) // Не пустая строка
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
        }

        private void textBoxDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
