﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public class Portion
    {
        public Medicine Medicine { set; get; }
        public double Amount { set; get; }

        public Portion(Medicine medicine, int amount) 
        {
            Medicine = medicine;
            Amount = amount;
        }
    }
}
