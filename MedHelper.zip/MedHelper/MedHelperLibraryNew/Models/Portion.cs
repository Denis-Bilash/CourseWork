﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс, что используеться для формирования поставки.
    public class Portion
    {
        public Portion(Medicine medicine, int amount) 
        {
            Medicine = new Medicine(medicine);
            Amount = amount;
        }
        public Medicine Medicine { private set; get; }
        public double Amount { private set; get; }
    }
}
