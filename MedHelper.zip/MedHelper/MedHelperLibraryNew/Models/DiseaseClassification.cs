﻿using MedHelperLibraryNew.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс что содержит список болезней.
    public class DiseaseClassification
    {
        public DiseaseClassification() 
        {
            Diseases = new List<Disease>();
        }
        public List<Disease> Diseases { private set; get; }

        // Сохраняем.
        public void Save()
        {
            new DiseaseLoader(this).Save();
        }
        // Загружаем.
        public void Load()
        {
            new DiseaseLoader(this).Load();
        }

        // Заполняем тестовыми данными.
        public void AddTestData(int n) 
        {
            for (int i = 0; i < n; i++) 
            {
                Disease temp;
                List<Illness> tempillness = new List<Illness>();
                for (int j = 0; j < 4; j++) 
                {
                    List<string> symptoms = new List<string>();
                    for (int k = 0; k < 4; k++) 
                    {
                        symptoms.Add($"Symptom #{j + k + i % (n - 1)}");
                    }
                    tempillness.Add(new Illness(symptoms, $"Name #{i+j}" , $"Illness description #{i+j}", $"Spreading #{i+j}", $"Treatmethod #{i+j}"));
                }
                temp = new Disease($"Disease #{i}", tempillness);
                Diseases.Add(temp);
            }
        }
    }
}
