﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public abstract class User
    {
        public string Login { set; get; }
        public string Password { set; get; }
        public string Access { get; set; }

        public User(string Login, string Password, string Access) 
        {
            this.Login = Login;
            this.Password = Password;
            this.Access = Access;
        }

    }
}
