﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Абстрактный класс, что характерезует пользователя.
    public abstract class User
    {
        public User(string Login, string Password, string Access) 
        {
            this.Login = Login;
            this.Password = Password;
            this.Access = Access;
        }
        public string Login {private set; get; }
        public string Password {private set; get; }
        // Устанавливает уровень доступа пользователя.
        public string Access { private set; get; }

    }
}
