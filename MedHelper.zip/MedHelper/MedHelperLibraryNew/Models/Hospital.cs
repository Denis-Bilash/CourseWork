﻿using MedHelperLibraryNew.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public class Hospital
    {
        public List<Medicine> Medicines { private set; get; }
        public List<Supply> Supplies { private set; get; }
        public List<Patient> Patients { private set; get; }

        public Hospital()
        {
            Medicines = new List<Medicine>();
            Supplies = new List<Supply>();
            Patients = new List<Patient>();
        }

        public void Save() 
        {
            new Dao(this).Save();
        }

        public void Load() 
        {
            new Dao(this).Load();
        }

        public void AddTestData(int n) 
        {
            //Medicines 
            for (int i = 0; i < n; i++)
            {
                List<string> replacement = new List<string>();
                for (int j = 0; j < i % 4; j++) 
                {
                    replacement.Add($"Replacement {i*j}");
                }
                Medicines.Add(new Medicine($"Medicine{i}", $"Medicine number{i}", "packages", i, replacement,null));
            }

            //Supplies
            for (int i = 0; i < n; i++)
            {
                List<Portion> portions = new List<Portion>();
                for (int j = 0; j < 4; j++) 
                {
                    portions.Add(new Portion(Medicines[(i + j) % n], j));
                }
                Supplies.Add(new Supply(portions, i));
            }

            //Patients
            for (int i = 0; i < n; i++) 
            {
                List<Medicine> med = new List<Medicine>();
                string birthdate = $"{i % 31:D2}.{i % 12:D2}.{1970 + (i % 50):D4}";
                string[] sex = { "Male", "Female" };
                Patients.Add(new Patient($"Patient{i}", $"Adress{i}", birthdate,sex[i%2],$"Description{i}"));
                for (int j= 0; j < 4; j++) 
                {
                    med.Add(new Medicine(Medicines[(i+j) %n]));
                    TreatmentInfo treatmentInfo = new TreatmentInfo(i, $"Complainment{j}", $"Diagnose{j}", $"Procedure{j}", med);
                    Patients[i].History.Add(treatmentInfo);
                }
            }
        }
    }
}
