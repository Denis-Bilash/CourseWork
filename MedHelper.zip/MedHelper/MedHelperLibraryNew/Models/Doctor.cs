﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Пользователи с доступом доктора.
    public class Doctor: User
    {
        public Doctor(string Login, string Password, string Access) : base(Login, Password, Access) { }
    }
}
