﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс, что содержит данные о пациенте.
    public class Patient
    {
        public Patient(string name, string adress, string birthdate, string sex, string description) 
        {
            Name = name;
            Adress = adress;
            Birthdate = birthdate;
            Sex = sex;
            Description = description;
            History = new List<TreatmentInfo>();
            TakeDate = DateTime.Now.AddDays(-1);    // могут воспользоваться Take Medicine.
        }

        public string Name { set; get; }
        public string Adress { set; get; }
        public string Birthdate { set; get; }
        public string Sex { set; get; }
        public string Description { set; get; }
        // Время, когда пациент в последний раз брал медикаменты.
        public DateTime TakeDate { set; get; }
        // История заболеваний пациента.
        public List<TreatmentInfo> History { get; set; }

        // Меняет дату взятия лекарства.
        public void ChangeTakeDade(DateTime date) 
        {
            TakeDate = date;
        }
    }
}
