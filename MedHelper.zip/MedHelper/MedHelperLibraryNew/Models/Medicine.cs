﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public class Medicine
    {
        static int id = 0;
        public int Id {private set; get; }
        public string Name { set; get; }
        public int Amount { set; get; }
        public string Description { set; get; }
        public string Unit { set; get; }
        public List<string> Replacements { set; get; }
        public Image Image { set; get; }

        public Medicine(string name, string description, string unit, int amount, List<string> replacements, Image img) 
        {
            Name = name;
            Description = description;
            Unit = unit;
            Amount += amount;
            Id = ++id;
            //Copy
            Replacements = new List<string>();
            if (replacements != null)
                Replacements.AddRange(replacements);
            // Добавляем картинку
            if (img == null)
                Image = new Bitmap(new DirectoryInfo(@"..\..\..").FullName + @"\Images\Default.jpg");
            Image = new Bitmap(Image, 50, 50);
        }

        public Medicine(Medicine other) 
        {
            this.Name = other.Name;
            this.Description = other.Description;
            this.Unit = other.Unit;
            this.Amount += other.Amount;
            Id = other.Id;
            Replacements = new List<string>();
            foreach (string s in other.Replacements)
                Replacements.Add(s);
            Image = (Bitmap)other.Image.Clone();

        }

        public override string ToString()
        {
            return Name;
        }

        public void ChangeAmmount(int number) 
        {
            Amount += number;
        }
    }
}
