﻿using MedHelperLibraryNew.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public class Disease
    {
        public string Name { set; get; }
        public List<Illness> Illnesses { set; get; }

        public Disease(string name, List<Illness> illnesses) 
        {
            Name = name;
            Illnesses = new List<Illness>();
            if (illnesses != null)
                Illnesses.AddRange(illnesses);
        }
    }
}
