﻿using MedHelperLibraryNew.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс для болезней
    public class Disease
    {
        public Disease(string name, List<Illness> illnesses) 
        {
            Name = name;
            Illnesses = new List<Illness>();
            if (illnesses != null)
                Illnesses.AddRange(illnesses);
        }
        public string Name { private set; get; }
        public List<Illness> Illnesses { private set; get; }
    }
}
