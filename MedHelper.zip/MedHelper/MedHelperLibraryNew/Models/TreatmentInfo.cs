﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    public class TreatmentInfo
    {
        public DateTime StartDate {set; get; }
        public DateTime EndDate {set; get; }
        public string Complainments { set; get; }
        public string Diagnosis { set; get; }
        public string Procedures { set; get; }
        public List<Medicine> Treatments { set; get;}

        public TreatmentInfo(int days, string complainments, string diagnosis, string procedures, List<Medicine> medicines)
        {
            StartDate = DateTime.Now;
            EndDate = StartDate.AddDays(days);
            Complainments = complainments;
            Diagnosis = diagnosis;
            Procedures = procedures;
            //copy
            Treatments = new List<Medicine>();
            if(medicines != null)
                Treatments.AddRange(medicines);
        }

        public override string ToString()     // Возвращает информацию о елементе
        {
            return StartDate.ToString() +  "     " + Diagnosis.Substring(0, Diagnosis.Length % 50) + "...";
        }
    }
}
