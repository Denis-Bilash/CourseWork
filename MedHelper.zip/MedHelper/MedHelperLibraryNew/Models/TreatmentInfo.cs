﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс что содержит данные о заболевании пациента. Используеться в истории болезней пациента.
    public class TreatmentInfo
    {
        public TreatmentInfo(int days, string complainments, string diagnosis, string procedures, List<Medicine> medicines)
        {
            StartDate = DateTime.Now;
            EndDate = StartDate.AddDays(days);
            Complainments = complainments;
            Diagnosis = diagnosis;
            Procedures = procedures;
            //copy
            Treatments = new List<Medicine>();
            if(medicines != null)
                Treatments.AddRange(medicines);
        }

        public DateTime StartDate { set; get; }
        public DateTime EndDate { set; get; }
        public string Complainments { set; get; }
        public string Diagnosis { set; get; }
        public string Procedures { set; get; }
        public List<Medicine> Treatments { private set; get; }

        // Возвращает информацию об елементе.
        public override string ToString()     
        {
            return StartDate.ToString() +  "     " + Diagnosis.Substring(0, Diagnosis.Length % 50) + "...";
        }
    }
}
