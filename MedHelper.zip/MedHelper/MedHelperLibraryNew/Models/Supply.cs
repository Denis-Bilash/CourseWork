﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibraryNew.Models
{
    [Serializable]
    // Класс поставки. Содержит список медикаментов и их количество.
    public class Supply
    {
        public Supply(List<Portion> portions)
        {
            Portions = portions;
            DateTime = DateTime.Now;
            Id = Guid.NewGuid().ToString();
        }

        // Конструктор для тестовых данных.
        public Supply(List<Portion> portions, int i)
        {
            Portions = portions;
            DateTime = DateTime.Now.AddDays(i).AddHours(i *2).AddSeconds(i*3) ;
            Id = Guid.NewGuid().ToString();
        }

        public List<Portion> Portions { private set; get; }
        public DateTime DateTime { private set; get; }
        public string Id { private set; get; }
    }
}

