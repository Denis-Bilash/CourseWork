﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MedHelperLibraryNew.DAL
{
    public class UsersLoader: IDisposable
    {
        string filePath = new DirectoryInfo(@"..\..\..").FullName + @"\accounts.txt";
        public List<User> users = new List<User>();
        public delegate void UsersLoaderError(string message);
        public event UsersLoaderError LoadError;


        public void Save() 
        {
            using (var wr = new StreamWriter(filePath))
            {
                foreach (User us in users)
                {
                    wr.WriteLine(us.Login);
                    wr.WriteLine(us.Password);
                    wr.WriteLine(us.Access);
                }
                wr.Close();
            }
        }

        public void Load() //Загружаем данные и проверяем их на правильность заполнения
        {
            using (var rd = new StreamReader(filePath))
            {
                if(users!= null)
                    users.Clear();
                string[] data = System.IO.File.ReadAllLines(filePath);
                for (int i = 0; i < data.Length; i += 3) 
                {
                    try
                    {
                        string login = data[i];
                        string password = data[i+1];
                        string access = data[i+2];
                        if (login == "" || password == "")
                        {
                            LoadError?.Invoke($"Empty login or password field in accaunt.txt on line#{i+1}");
                            throw new Exception("Handled");
                        }

                        // Создаем класс в зависимости от уровня доступа
                        if (access == "Admin") 
                            users.Add(new Admin(login, password, access));
                        else if (access == "Doctor")
                            users.Add(new Doctor(login, password, access));
                        else
                        {
                            LoadError?.Invoke($"Invalid access discription, check accounts.txt. Line{i + 3}. Only values Admin and Doctor are allowed.");
                            throw new Exception("Handled");
                        }
                    }
                    catch(Exception e) 
                    {
                        //if (users != null)    // Не позволяет пользователю войти, при любой ошибке в accaunt.txt, даже если его аккаунт нашелся
                        //    users.Clear();
                        if (e.Message != "Handled")
                            LoadError.Invoke($"Invalid data format, check accounts.txt at line #{i + 1}");
                        break;                    
                    }
                }
                rd.Close();
            }
        }

        public void AddTestData(int n) 
        {
            users.Clear();
            for (int i = 0; i < n / 2; i++)
            {
                users.Add(new Admin(Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), "Admin"));
                users.Add(new Doctor(Guid.NewGuid().ToString(), Guid.NewGuid().ToString(), "Doctor"));
            }
        }

        public void Dispose() 
        {
            filePath = "";
            if(users!= null)
                users.Clear();
        }

    }
}
