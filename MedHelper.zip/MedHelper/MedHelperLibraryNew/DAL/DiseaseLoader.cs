﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace MedHelperLibraryNew.DAL
{
    // Нужен для загрузки фала с болезнями.
    public class DiseaseLoader 
    {
        public DiseaseClassification diseases;

        // Находим относительный путь к файлу и загружаем его
        public DiseaseLoader(DiseaseClassification diseases) 
        {
            this.diseases = diseases;
            FilePath = new DirectoryInfo(@"..\..\..").FullName + @"\Diseases.bin";
        }
        string FilePath { get; }

        // Сохраняем данные
        public void Save()
        {
            using (Stream stream = File.Create(FilePath))
            {
                var serializer = new BinaryFormatter();
                serializer.Serialize(stream, diseases);
            }
        }

        // Загружаем данные из файла
        public void Load()
        {
            using (Stream stream = File.OpenRead(FilePath))
            {
                var serializer = new BinaryFormatter();
                DiseaseClassification temp = (DiseaseClassification)serializer.Deserialize(stream);
                Copy(temp.Diseases, diseases.Diseases);
            }

            void Copy<T>(List<T> from, List<T> to)
            {
                to.Clear();
                to.AddRange(from);
            }
        }

    }
}
