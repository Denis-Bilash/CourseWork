﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace MedHelperLibraryNew.DAL
{
    public class DiseaseLoader //: IDisposable
    {
        string filePath = new DirectoryInfo(@"..\..\..").FullName + @"\Diseases.bin";
        public DiseaseClassification diseases;

        public DiseaseLoader(DiseaseClassification diseases) 
        {
            this.diseases = diseases;
        }

        public void Save()
        {
            using (Stream stream = File.Create(filePath))
            {
                var serializer = new BinaryFormatter();
                serializer.Serialize(stream, diseases);
            }
        }

        public void Load()
        {
            using (Stream stream = File.OpenRead(filePath))
            {
                var serializer = new BinaryFormatter();
                DiseaseClassification temp = (DiseaseClassification)serializer.Deserialize(stream);
                Copy(temp.Diseases, diseases.Diseases);
            }

            void Copy<T>(List<T> from, List<T> to)
            {
                to.Clear();
                to.AddRange(from);
            }
        }

    }
}
