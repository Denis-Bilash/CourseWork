﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace MedHelperLibraryNew.DAL
{
    public class Dao
    {
        Hospital hospital;
        string filePath = new DirectoryInfo(@"..\..\..").FullName + @"\MedHelper.bin";


        public Dao(Hospital hospital)
        {
            this.hospital = hospital;
        }

        public void Save()
        {
            using (Stream stream = File.Create(filePath))
            {
                var serializer = new BinaryFormatter();
                serializer.Serialize(stream, hospital);
            }
        }

        public void Load()
        {
            using (Stream stream = File.OpenRead(filePath))
            {
                var serializer = new BinaryFormatter();
                Hospital temp = (Hospital)serializer.Deserialize(stream);
                Copy(temp.Medicines, hospital.Medicines);
                Copy(temp.Supplies, hospital.Supplies);
                Copy(temp.Patients, hospital.Patients);
            }

            void Copy<T>(List<T> from, List<T> to)
            {
                to.Clear();
                to.AddRange(from);
            }
        }
    }
}
