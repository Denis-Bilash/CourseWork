﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;

namespace MedHelperLibraryNew.DAL
{
    // Загружает и сохраняет класс Hospital.
    public class Dao
    {
        // находим относительный путь к файлу.
        public Dao(Hospital hospital)
        {
            this.Hospital = hospital;
            FilePath = new DirectoryInfo(@"..\..\..").FullName + @"\MedHelper.bin";
        }
        Hospital Hospital { get; }
        string FilePath { get; }

        // Сериализируем данные в файл.
        public void Save()
        {
            using (Stream stream = File.Create(FilePath))
            {
                var serializer = new BinaryFormatter();
                serializer.Serialize(stream, Hospital);
            }
        }

        //Загружаем данные из бинарного файла.
        public void Load()
        {
            using (Stream stream = File.OpenRead(FilePath))
            {
                var serializer = new BinaryFormatter();
                Hospital temp = (Hospital)serializer.Deserialize(stream);
                Copy(temp.Medicines, Hospital.Medicines);
                Copy(temp.Supplies, Hospital.Supplies);
                Copy(temp.Patients, Hospital.Patients);
            }

            void Copy<T>(List<T> from, List<T> to)
            {
                to.Clear();
                to.AddRange(from);
            }
        }
    }
}
