﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibrary.Models
{
    [Serializable]
    public class Patient
    {
        public string Name { set; get; }
        public string Adress { set; get; }
        public string Birthdate {set; get; }
        public string Sex { set; get; }
        public string Description { set; get; }

        public List<TreatmentInfo> History { get; set; }

        public Patient(string name, string adress, string birthdate, string sex, string description) 
        {
            Name = name;
            Adress = adress;
            Birthdate = birthdate;
            Sex = sex;
            Description = description;
            History = new List<TreatmentInfo>();
        }
}
}
