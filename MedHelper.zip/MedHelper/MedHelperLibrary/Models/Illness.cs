﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibrary.Models
{
    [Serializable]
    public class Illness
    {
        public List<string> Symptoms { private set; get; }
        public string Description { private set; get; }
        public string TreatMethods { private set; get; }
        public string Spreading { private set; get; }

        // Construktor for testing
        public Illness(List<string> symptoms, string description, string spreading, string treatmethod) 
        {
            Description = description;
            TreatMethods = treatmethod;
            Spreading = spreading;
        }

    }
}
