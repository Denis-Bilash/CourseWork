﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibrary.Models
{
    [Serializable]
    public class Supply
    {
        public Supply(List<Portion> portions)
        {
            Portions = portions;
            DateTime = DateTime.Now;
            Id = ++id;
        }

        //Construktor for testing
        public Supply(List<Portion> portions, int i)
        {
            Portions = portions;
            DateTime = DateTime.Now;
            DateTime.AddDays(i);
            DateTime.AddHours(i * 2);
            DateTime.AddSeconds(i * 3);
            Id = ++id;
        }

        public List<Portion> Portions { private set; get; }
        public DateTime DateTime { private set; get; }
        static int id = 0;
        public int Id { private set; get; }
    }
}

