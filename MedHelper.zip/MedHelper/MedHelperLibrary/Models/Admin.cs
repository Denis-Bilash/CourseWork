﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibrary.Models
{
    [Serializable]
    public class Admin: User
    {
        public Admin(string Login, string Password, string Access) : base(Login, Password, Access) { }
    }
}
