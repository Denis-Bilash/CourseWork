﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedHelperLibrary.Models
{
    [Serializable]
    public class Medicine
    {
        static int id = 0;
        public int Id {private set; get; }
        public string Name { set; get; }
        public int Amount { set; get; }
        public string Description { set; get; }
        public string Unit { set; get; }
        public List<string> Replacements { set; get; }

        public Medicine(string name, string description, string unit, int amount, List<string> replacements) 
        {
            Name = name;
            Description = description;
            Unit = unit;
            Amount += amount;
            Id = ++id;
            //Copy
            Replacements = new List<string>();
            if (replacements != null)
                Replacements.AddRange(replacements);
        }

        public Medicine(Medicine other) 
        {
            this.Name = other.Name;
            this.Description = other.Description;
            this.Unit = other.Unit;
            this.Amount += other.Amount;
            Id = ++id;
            Replacements = new List<string>();
            foreach (string s in other.Replacements)
                Replacements.Add(s);
        }

        public override string ToString()
        {
            return Name;
        }

        public void ChangeAmmount(int number) 
        {
            Amount += number;
        }
    }
}
