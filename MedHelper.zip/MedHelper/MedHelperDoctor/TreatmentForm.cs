﻿using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class TreatmentForm : Form
    {
        TreatmentInfo currTreatment;
        public TreatmentForm(TreatmentInfo sended)
        {
            InitializeComponent();
            currTreatment = sended;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxComplainment.Text == "")
            { MessageBox.Show("Complainment field must not be empty", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxDiagnose.Text == "")
            { MessageBox.Show("Diagnose field must not be empty ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (dateTimePicker1.Value == dateTimePicker1.MinDate)
            {   var rez = MessageBox.Show("The treatment date hasn't been changed. Are you sure you want to continue?", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (rez == DialogResult.Cancel)
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            // Сохраняем данные (без привязки)
            currTreatment.StartDate = dateTimePicker1.MinDate;
            currTreatment.EndDate = dateTimePicker1.Value;
            currTreatment.Complainments = textBoxComplainment.Text;
            currTreatment.Diagnosis = textBoxDiagnose.Text;
            currTreatment.Procedures = textBoxProcedures.Text;

            // Проверяем введенные лекарства
            for (int i = 0; i < currTreatment.Treatments.Count; i++)
            {
                if (currTreatment.Treatments[i].Name.TrimStart() == "" || currTreatment.Treatments[i].Amount <= 0)                
                {
                    MessageBox.Show($"Invalid value at line #{i}.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    DialogResult = DialogResult.None;
                    return;
                }
            }
        }

        private void TreatmentForm_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button2_Click(object sender, EventArgs e) // добавляем строку с медикаментами
        {
            currTreatment.Treatments.Add(new Medicine("","","",0,null));
            medicineBindingSource.ResetBindings(false);
        }

        private void button3_Click(object sender, EventArgs e)  // Удаляем выбраный медикамент
        {
            if (currTreatment.Treatments.Count > 0)
            {
                int index = dataGridView1.SelectedCells[0].RowIndex;
                if (index != -1)
                {
                    currTreatment.Treatments.RemoveAt(index);
                    medicineBindingSource.ResetBindings(false);
                }
            }
        }
    }
}
