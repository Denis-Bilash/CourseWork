﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class TreatmentForm : Form
    {
        TreatmentInfo CurrTreatment { get; }
        Hospital Hospital { get; }
        public TreatmentForm(TreatmentInfo sended, Hospital secondsended)
        {
            InitializeComponent();
            CurrTreatment = sended;
            Hospital = secondsended;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxComplainment.Text == "")
            { ShowWarning("Complainment field must not be empty");
                return; 
            }
            if (textBoxDiagnose.Text == "")
            { ShowWarning("Diagnose field must not be empty ");
                return;
            }           

            //********************************
            List<Medicine> medicines = new List<Medicine>();
            //ПРОВЕВКА ВВЕДЕННЫХ ЗНАЧЕНИЙ
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                //Проверка на правильность ввода
                string name = (string)dataGridView1.Rows[i].Cells[0].Value;
                string amount = (string)dataGridView1.Rows[i].Cells[1].Value;
                if (name == null || amount == null) 
                {
                    CellValidationWarning($"Empty value at line #{i}", i, 1);
                    return;
                }

                name = name.Trim(' ');
                amount = amount.TrimStart('0');
                amount = amount.Trim(' ');
                
                if (ValidateSupplyName(name, i) == false || ValidateSupplyAmount(amount,i) == false)
                { // Имя или количество в строке невалидно
                    return;
                }

                //Проверка на соответствие с медикаментом
                int index = Hospital.Medicines.FindIndex((x) => x.Name.ToUpper() == name.ToUpper());
                if (index != -1)
                {// Лекарство существует
                    medicines.Add(new Medicine(Hospital.Medicines[index], Convert.ToInt32(amount)));//Копируем лекарство с описаннием в этот момент времени 
                }
                else 
                {// Лекарство имеет валидное имя, но его нет в медикаментах
                 // Добавляем его в TreatmentInfo
                    medicines.Add(new Medicine(name, "", "", Convert.ToInt32(amount), null, null));
                }
            }

            if (dateTimePicker1.Value == dateTimePicker1.MinDate)
            {
                var rez = MessageBox.Show("The treatment date hasn't been changed. Are you sure you want to continue?", 
                                                "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (rez == DialogResult.Cancel)
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            //На этом этапе есть список назначений. Осталось обновить данные 

            CurrTreatment.Treatments.AddRange(medicines);

            //********************************

            // Сохраняем данные (без привязки)
            CurrTreatment.StartDate = dateTimePicker1.MinDate;
            CurrTreatment.EndDate = dateTimePicker1.Value;
            CurrTreatment.Complainments = textBoxComplainment.Text;
            CurrTreatment.Diagnosis = textBoxDiagnose.Text;
            CurrTreatment.Procedures = textBoxProcedures.Text;

        }

        public bool ValidateSupplyAmount(string amount, int rowindex)
        {
            if (amount == "")
            {
                CellValidationWarning($"Empty value at line #{rowindex}", rowindex, 1);              
                return false;
            }
            foreach (char c in amount)
            {
                if (!Char.IsDigit(c))
                {
                    CellValidationWarning($"Invalid medicine amount at line #{rowindex}", rowindex, 1);
                    return false;
                }
            }
            return true;
        }

        public bool ValidateSupplyName(string name, int rowindex)
        {
            if (name == "")
            {
                CellValidationWarning($"Empty value at line #{rowindex}", rowindex, 0);
                return false;
            }
            foreach (char c in name)
            {
                if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))
                {
                    CellValidationWarning($"Invalid medicine name at line #{rowindex}", rowindex,0);
                    return false;
                }
            }
            return true;
        }

        public void CellValidationWarning(string message, int rowindex, int columnindex)
        {
            MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            dataGridView1.ClearSelection();
            dataGridView1.Rows[rowindex].Selected = true;
            dataGridView1.Columns[columnindex].Selected = true;
            DialogResult = DialogResult.None;
        }

        public void ShowWarning(string message)
        {
            MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
        }

        private void TreatmentForm_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void Button2_Click(object sender, EventArgs e) // добавляем строку с медикаментами
        {
            dataGridView1.Rows.Add(new DataGridViewRow());
            medicineBindingSource.ResetBindings(false);
        }

        private void Button3_Click(object sender, EventArgs e)  // Удаляем выбраный медикамент
        {
            if (dataGridView1.CurrentRow.IsNewRow == false) // Не пустая строка
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
        }
    }
}
