﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class TreatmentForm : Form
    {
        TreatmentInfo currTreatment;
        Hospital hospital;
        public TreatmentForm(TreatmentInfo sended, Hospital secondsended)
        {
            InitializeComponent();
            currTreatment = sended;
            hospital = secondsended;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxComplainment.Text == "")
            { MessageBox.Show("Complainment field must not be empty", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxDiagnose.Text == "")
            { MessageBox.Show("Diagnose field must not be empty ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (dateTimePicker1.Value == dateTimePicker1.MinDate)
            {   var rez = MessageBox.Show("The treatment date hasn't been changed. Are you sure you want to continue?", "Info", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (rez == DialogResult.Cancel)
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            //********************************
            List<Medicine> medicines = new List<Medicine>();
            //ПРОВЕВКА ВВЕДЕННЫХ ЗНАЧЕНИЙ
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                //Проверка на правильность ввода
                string name = (string)dataGridView1.Rows[i].Cells[0].Value;
                string amount = (string)dataGridView1.Rows[i].Cells[1].Value;
                if (name == null || amount == null) 
                {
                    MessageBox.Show($"Empty value at line #{i}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[i].Selected = true;
                    dataGridView1.Columns[1].Selected = true;
                    buttonSave.DialogResult = DialogResult.None;
                    return;
                }

                name = name.Trim(' ');
                amount = amount.TrimStart('0');
                amount = amount.Trim(' ');
                
                if (ValidateSupplyName(name, i) == false || ValidateSupplyAmount(amount,i) == false)
                { // Имя или количество в строке невалидно
                    buttonSave.DialogResult = DialogResult.None;
                    return;
                }

                //Проверка на соответствие с медикаментом
                int index = hospital.Medicines.FindIndex((x) => x.Name.ToUpper() == name.ToUpper());
                if (index != -1)
                {// Лекарство существует
                    medicines.Add(new Medicine(hospital.Medicines[index], Convert.ToInt32(amount)));//Копируем лекарство с описаннием в этот момент времени 
                }
                else 
                {// Лекарство имеет валидное имя, но его нет в медикаментах
                 // Добавляем его в TreatmentInfo
                    medicines.Add(new Medicine(name, "", "", Convert.ToInt32(amount), null, null));
                }
            }

            //На этом этапе есть список назначений. Осталось обновить данные 

            currTreatment.Treatments.AddRange(medicines);

            //********************************

            // Сохраняем данные (без привязки)
            currTreatment.StartDate = dateTimePicker1.MinDate;
            currTreatment.EndDate = dateTimePicker1.Value;
            currTreatment.Complainments = textBoxComplainment.Text;
            currTreatment.Diagnosis = textBoxDiagnose.Text;
            currTreatment.Procedures = textBoxProcedures.Text;

        }

        public bool ValidateSupplyAmount(string amount, int rowindex)
        {
            if (amount == "")
            {
                MessageBox.Show($"Empty value at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[rowindex].Selected = true;
                dataGridView1.Columns[1].Selected = true;
                return false;
            }
            foreach (char c in amount)
            {
                if (!Char.IsDigit(c))
                {
                    MessageBox.Show($"Invalid medicine amount at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[rowindex].Selected = true;
                    dataGridView1.Columns[1].Selected = true;
                    return false;
                }
            }
            return true;
        }

        public bool ValidateSupplyName(string name, int rowindex)
        {
            if (name == "")
            {
                MessageBox.Show($"Empty value at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dataGridView1.ClearSelection();
                dataGridView1.Rows[rowindex].Selected = true;
                dataGridView1.Columns[0].Selected = true;
                return false;
            }
            foreach (char c in name)
            {
                if (!Char.IsLetterOrDigit(c) && !Char.IsWhiteSpace(c))
                {
                    MessageBox.Show($"Invalid medicine name at line #{rowindex}", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    dataGridView1.ClearSelection();
                    dataGridView1.Rows[rowindex].Selected = true;
                    dataGridView1.Columns[0].Selected = true;
                    return false;
                }
            }
            return true;
        }

        private void TreatmentForm_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button2_Click(object sender, EventArgs e) // добавляем строку с медикаментами
        {
            dataGridView1.Rows.Add(new DataGridViewRow());
            medicineBindingSource.ResetBindings(false);
        }

        private void button3_Click(object sender, EventArgs e)  // Удаляем выбраный медикамент
        {
            if (dataGridView1.CurrentRow.IsNewRow == false) // Не пустая строка
                dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
        }

        private void TreatmentForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (buttonSave.DialogResult == DialogResult.None)
            {
                buttonSave.DialogResult = DialogResult.Yes;
                e.Cancel = true;
            }
        }
    }
}
