﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DiseasesViewer : Form
    {
        DiseaseClassification diseasetree;
        public DiseasesViewer(DiseaseClassification sended)
        {
            InitializeComponent();
            diseasetree = sended;
        }

        private void DiseasesViewer_Load(object sender, EventArgs e)
        {
            TreeNode DesiaseBase = new TreeNode("DesiaseBase");
            // Заповляем дерево
            for (int i = 0; i < diseasetree.Diseases.Count; i++) 
            {
                TreeNode desiase = new TreeNode(diseasetree.Diseases[i].Name);
                for (int j = 0; j < diseasetree.Diseases[i].Illnesses.Count; j++) 
                {
                    TreeNode illness = new TreeNode(diseasetree.Diseases[i].Illnesses[j].Name);

                    TreeNode symptoms = new TreeNode("Symptoms");
                    for (int k = 0; k < diseasetree.Diseases[i].Illnesses[j].Symptoms.Count; k++) 
                    {
                        symptoms.Nodes.Add(new TreeNode(diseasetree.Diseases[i].Illnesses[j].Symptoms[k]));
                    }
                    illness.Nodes.Add(symptoms);

                    TreeNode description = new TreeNode("Description");
                    description.Nodes.Add(new TreeNode(diseasetree.Diseases[i].Illnesses[j].Description));
                    illness.Nodes.Add(description);

                    TreeNode treatmethods = new TreeNode("TreatMethods");
                    treatmethods.Nodes.Add(new TreeNode(diseasetree.Diseases[i].Illnesses[j].TreatMethods));
                    illness.Nodes.Add(treatmethods);

                    TreeNode spreading = new TreeNode("Spreading");
                    spreading.Nodes.Add(new TreeNode(diseasetree.Diseases[i].Illnesses[j].Spreading));
                    illness.Nodes.Add(spreading);

                    desiase.Nodes.Add(illness);
                }
                DesiaseBase.Nodes.Add(desiase);
            }
            treeView1.Nodes.Add(DesiaseBase);
            treeView1.Nodes[0].Expand();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Level == 2) 
            {
                labelName.Text = e.Node.Text;
                int diseaseIndex = e.Node.Parent.Index;
                int illnessIndex = e.Node.Index;

                Illness currIllness = diseasetree.Diseases[diseaseIndex].Illnesses[illnessIndex];
                labelName.Text = currIllness.Name;
                textBoxDescription.Text = currIllness.Description;
                textBoxSpreading.Text = currIllness.Spreading;
                textBoxTreat.Text = currIllness.TreatMethods;
                listBox1.DataSource = currIllness.Symptoms;
                listBox1.SelectedIndex = -1;
            }
        }
    }
}
