﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DiseasesViewer : Form
    {
        DiseaseClassification Diseasetree { get; }
        [DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);
        public DiseasesViewer(DiseaseClassification sended)
        {
            InitializeComponent();
            Diseasetree = sended;
        }

        private void DiseasesViewer_Load(object sender, EventArgs e)
        {
            TreeNode DesiaseBase = new TreeNode("DesiaseBase");
            // Заповляем дерево
            for (int i = 0; i < Diseasetree.Diseases.Count; i++) 
            {
                TreeNode desiase = new TreeNode(Diseasetree.Diseases[i].Name);
                for (int j = 0; j < Diseasetree.Diseases[i].Illnesses.Count; j++) 
                {
                    TreeNode illness = new TreeNode(Diseasetree.Diseases[i].Illnesses[j].Name);

                    TreeNode symptoms = new TreeNode("Symptoms");
                    for (int k = 0; k < Diseasetree.Diseases[i].Illnesses[j].Symptoms.Count; k++) 
                    {
                        symptoms.Nodes.Add(new TreeNode(Diseasetree.Diseases[i].Illnesses[j].Symptoms[k]));
                    }
                    illness.Nodes.Add(symptoms);

                    TreeNode description = new TreeNode("Description");
                    description.Nodes.Add(new TreeNode(Diseasetree.Diseases[i].Illnesses[j].Description));
                    illness.Nodes.Add(description);

                    TreeNode treatmethods = new TreeNode("TreatMethods");
                    treatmethods.Nodes.Add(new TreeNode(Diseasetree.Diseases[i].Illnesses[j].TreatMethods));
                    illness.Nodes.Add(treatmethods);

                    TreeNode spreading = new TreeNode("Spreading");
                    spreading.Nodes.Add(new TreeNode(Diseasetree.Diseases[i].Illnesses[j].Spreading));
                    illness.Nodes.Add(spreading);

                    desiase.Nodes.Add(illness);
                }
                DesiaseBase.Nodes.Add(desiase);
            }
            treeView1.Nodes.Add(DesiaseBase);
            treeView1.Nodes[0].Expand();
        }

        private void TreeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            int diseaseIndex = -1;
            int illnessIndex = -1;
            if (e.Node.Level == 2)
            {
                labelName.Text = e.Node.Text;
                diseaseIndex = e.Node.Parent.Index;
                illnessIndex = e.Node.Index;
            }
            else if (e.Node.Level == 3)
            {
                diseaseIndex = e.Node.Parent.Parent.Index;
                illnessIndex = e.Node.Parent.Index;
            }
            else if (e.Node.Level == 4)
            {
                diseaseIndex = e.Node.Parent.Parent.Parent.Index;
                illnessIndex = e.Node.Parent.Parent.Index;
            }

            if (diseaseIndex != -1 && illnessIndex != -1)
            {
                Illness currIllness = Diseasetree.Diseases[diseaseIndex].Illnesses[illnessIndex];
                labelName.Text = currIllness.Name;
                textBoxDescription.Text = currIllness.Description;
                textBoxSpreading.Text = currIllness.Spreading;
                textBoxTreat.Text = currIllness.TreatMethods;
                listBox1.DataSource = currIllness.Symptoms;
                listBox1.SelectedIndex = -1;
            }
            else
            {
                labelName.Text = "";
                textBoxDescription.Text = "";
                textBoxSpreading.Text = "";
                textBoxTreat.Text = "";
                listBox1.DataSource = null;
                listBox1.SelectedIndex = -1;
            }
        }

        private void TextBoxTreat_MouseClick(object sender, MouseEventArgs e)
        {
            HideCaret(textBoxDescription.Handle);
            HideCaret(textBoxSpreading.Handle);
            HideCaret(textBoxTreat.Handle);
        }
    }
}
