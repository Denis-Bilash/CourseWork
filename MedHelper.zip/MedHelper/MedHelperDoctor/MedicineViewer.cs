﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class MedicineViewer : Form
    {
        Hospital hospital;
        public MedicineViewer(Hospital sended)
        {
            InitializeComponent();
            hospital = sended;
            medicineBindingSource.DataSource = hospital.Medicines;
        }

        private void MedicineViewer_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if ( index != -1) 
            {
                MedInfo MedicineInfo = new MedInfo(hospital.Medicines[index]);
                MedicineInfo.ShowDialog();
            }
            else 
                MessageBox.Show("You need to select a medicine", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information); 
        }
    }
}
