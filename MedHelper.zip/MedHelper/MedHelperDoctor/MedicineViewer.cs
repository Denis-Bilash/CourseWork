﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class MedicineViewer : Form
    {
        Hospital Hospital { get; }
        public MedicineViewer(Hospital sended)
        {
            InitializeComponent();
            Hospital = sended;
            medicineBindingSource.DataSource = Hospital.Medicines;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Info();
        }

        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Info();
        }

        public void Info() 
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                MedInfo MedicineInfo = new MedInfo(Hospital.Medicines[index]);
                MedicineInfo.ShowDialog();
            }
            else
                MessageBox.Show("You need to select a medicine", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
