﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class NewPatientForm : Form
    {
        Patient CurrPatient { get; }
        Hospital Hospital { get; }
        public NewPatientForm(Patient sended, Hospital secondsended)
        {
            InitializeComponent();
            CurrPatient = sended;
            Hospital = secondsended;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "")
            {   ShowWarning("Invalid name"); 
                return; 
            }
            if (textBoxName.Text.Trim(' ') != textBoxName.Text)
            {
                var rez = MessageBox.Show("Invalid wightspaces at the name field. Do you want to delete them?", "Warning", MessageBoxButtons.YesNo,
                  MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    textBoxName.Text = textBoxName.Text.Trim(' ');
                else
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }
            if (textBoxAdress.Text == "")
            {    ShowWarning("Invalid unit ");
                    return; 
            }
            if (comboBoxSex.Text == "")
            {   ShowWarning("Incorrect sex field value"); 
                return;
            }
            if (!maskedTextBoxBirthdate.MaskCompleted)
            {    ShowWarning("Invalid birth date "); 
                 return; 
            }
            else 
            {
                try
                { DateTime dateTime = Convert.ToDateTime(maskedTextBoxBirthdate.Text);
                    if (dateTime > DateTime.Now  || dateTime .AddYears(150)<DateTime.Now)
                        throw new System.FormatException();
                }
                catch (System.FormatException)
                {
                    ShowWarning("Invalid birth date "); 
                    return;
                }
            }

                if (Hospital.FindPatientIndex(textBoxName.Text) != -1) 
                {
                    ShowWarning("Patient with such a name is already exists"); 
                    return;
                }

            // Сохраняем данные (без привязки)
            CurrPatient.Name = textBoxName.Text;
            CurrPatient.Description = textBoxDescription.Text;
            CurrPatient.Adress = textBoxAdress.Text;
            CurrPatient.Sex = comboBoxSex.Text;
            CurrPatient.Birthdate = maskedTextBoxBirthdate.Text;           
        }

        public void ShowWarning(string message)
        {
            MessageBox.Show(message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            DialogResult = DialogResult.None;
        }

        private void TextBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }

        }

        private void TextBoxAdress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',' && e.KeyChar != '-')
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void NewPatientForm_Load(object sender, EventArgs e)
        {

        }
    }
}
