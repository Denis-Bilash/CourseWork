﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class NewPatientForm : Form
    {
        Patient currPatient;
        Hospital hospital;
        public NewPatientForm(Patient sended, Hospital secondsended)
        {
            InitializeComponent();
            currPatient = sended;
            hospital = secondsended;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "")
            { MessageBox.Show("Invalid name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxName.Text.Trim(' ') != textBoxName.Text)
            {
                var rez = MessageBox.Show("Invalid wightspaces at the name field. Do you want to delete them?", "Warning", MessageBoxButtons.YesNo,
                  MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    textBoxName.Text = textBoxName.Text.Trim(' ');
                else
                {
                    DialogResult = DialogResult.None;
                    return;
                }
            }
            if (textBoxAdress.Text == "")
            { MessageBox.Show("Invalid unit ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (comboBoxSex.Text == "")
            { MessageBox.Show("Incorrect sex field value", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (!maskedTextBoxBirthdate.MaskCompleted)
            { MessageBox.Show("Invalid birth date ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            else 
            {
                try
                { DateTime dateTime = Convert.ToDateTime(maskedTextBoxBirthdate.Text);
                    if (dateTime > DateTime.Now  || dateTime .AddYears(150)<DateTime.Now)
                        throw new System.FormatException();
                }
                catch (System.FormatException)
                {
                    MessageBox.Show("Invalid birth date ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                    DialogResult = DialogResult.None; 
                    return;
                }
            }

            foreach (Patient patient in hospital.Patients) 
            {
                if (patient.Name == textBoxName.Text) 
                {
                    MessageBox.Show("Patient with such a name is already exists", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
                    DialogResult = DialogResult.None; 
                    return;
                }
            }

            // Сохраняем данные (без привязки)
            currPatient.Name = textBoxName.Text;
            currPatient.Description = textBoxDescription.Text;
            currPatient.Adress = textBoxAdress.Text;
            currPatient.Sex = comboBoxSex.Text;
            currPatient.Birthdate = maskedTextBoxBirthdate.Text;           
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && !Char.IsWhiteSpace(e.KeyChar)) 
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }

        }

        private void textBoxAdress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',' && e.KeyChar != '-')
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }

        private void NewPatientForm_Load(object sender, EventArgs e)
        {

        }
    }
}
