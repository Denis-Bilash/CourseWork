﻿using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class RecepitionForm : Form
    {
        Hospital hospital;
        public RecepitionForm(Hospital sended)
        {
            InitializeComponent();
            hospital = sended;
        }

        private void RecepitionForm_Load(object sender, EventArgs e)
        {
            hospitalBindingSource.DataSource = hospital.Patients;
            int count = dataGridView1.Columns.Count;
            dataGridView1.Columns[count-1].Visible = false;
            dataGridView1.Columns[count - 2].Visible = false;
        }

        private void AddNewPatient_Click(object sender, EventArgs e)
        {
            Patient temp = new Patient("","","","","");
            NewPatientForm NewPatientForm = new NewPatientForm(temp);
            if (NewPatientForm.ShowDialog() == DialogResult.Yes) 
            {
                hospital.Patients.Add(temp);
                hospitalBindingSource.ResetBindings(false);    
                int index = hospital.Patients.FindIndex(x => x.Name.Contains(temp.Name));  // Ищем индекс добавленного пациента в массиве
                Treatment(index);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Treatment(dataGridView1.SelectedRows[0].Index);  // Мы можем выбрать лишь одну строку в таблице
        }

        public void Treatment(int index) 
        {
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                TreatmentInfo temp = new TreatmentInfo(0, "", "", "", null);
                TreatmentForm TreatmentForm = new TreatmentForm(temp);
                if (TreatmentForm.ShowDialog() == DialogResult.Yes)
                {
                    patient.History.Add(temp);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                PatientInfo PatientInfoForm = new PatientInfo(patient);
                PatientInfoForm.ShowDialog();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                TreatmentInfo treatmentInfo = patient.History[patient.History.Count - 1];
                if (treatmentInfo.EndDate > DateTime.Now)
                {
                    TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(treatmentInfo, hospital);
                    TreatmentInfoForm.ShowDialog();
                }
                else 
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
