﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class RecepitionForm : Form
    {
        Hospital hospital;
        AutoCompleteStringCollection AutoCompletePatientsource = new AutoCompleteStringCollection();
        bool IsDirty = false;

        public RecepitionForm(Hospital sended)
        {
            InitializeComponent();
            hospital = sended;
        }

        private void RecepitionForm_Load(object sender, EventArgs e)
        {
            hospitalBindingSource.DataSource = hospital.Patients;
            int count = dataGridView1.Columns.Count;
            dataGridView1.Columns[count-1].Visible = false;
            dataGridView1.Columns[count - 2].Visible = false;

            //Для автозаполнения
            AutoCompliteCorrection();
            
        }

        public void AutoCompliteCorrection() 
        {
            AutoCompletePatientsource = new AutoCompleteStringCollection();
            for (int i = 0; i < hospital.Patients.Count; i++)
                AutoCompletePatientsource.Add(hospital.Patients[i].Name);

            textBoxSearch.AutoCompleteCustomSource = AutoCompletePatientsource;
            textBoxSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBoxSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void AddNewPatient_Click(object sender, EventArgs e)
        {
            Patient temp = new Patient("","","","","");
            NewPatientForm NewPatientForm = new NewPatientForm(temp, hospital);
            if (NewPatientForm.ShowDialog() == DialogResult.Yes) 
            {
                hospital.Patients.Add(temp);
                hospitalBindingSource.ResetBindings(false);
                IsDirty = true;
                AutoCompliteCorrection();
                int index = hospital.Patients.FindIndex(x => x.Name == temp.Name);  // Ищем индекс добавленного пациента в массиве               
                Treatment(index);              
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Treatment(dataGridView1.SelectedRows[0].Index);  // Мы можем выбрать лишь одну строку в таблице
        }

        public void Treatment(int index) 
        {
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                TreatmentInfo temp = new TreatmentInfo(0, "", "", "", null);
                TreatmentForm TreatmentForm = new TreatmentForm(temp,hospital);
                if (TreatmentForm.ShowDialog() == DialogResult.Yes)
                {
                    patient.History.Add(temp);
                    IsDirty = true;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                PatientInfo PatientInfoForm = new PatientInfo(patient, hospital);
                if (PatientInfoForm.ShowDialog() == DialogResult.Yes)
                {
                    hospitalBindingSource.ResetBindings(false);
                    IsDirty = true;
                    AutoCompliteCorrection();
                }


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                TreatmentInfo treatmentInfo = patient.History[patient.History.Count - 1];
                if (treatmentInfo.EndDate > DateTime.Now)
                {
                    TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(treatmentInfo, hospital);
                    TreatmentInfoForm.ShowDialog();

                }
                else 
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            int index = hospital.Patients.FindIndex(x => x.Name == textBoxSearch.Text);
            if (index != -1)
            {
                dataGridView1.Rows[index].Cells[0].Selected = true;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiseaseClassification diseasetree;
            diseasetree = new DiseaseClassification();
            diseasetree.Load();

            DiseasesViewer DiseasesViewer = new DiseasesViewer(diseasetree);
            DiseasesViewer.ShowDialog();
        }

        private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MedicineViewer MedicineViewer = new MedicineViewer(hospital);
            MedicineViewer.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RecepitionForm_FormClosing(object sender, FormClosingEventArgs e)
        { 
            if (IsDirty)
            {
                var rez = MessageBox.Show("Do you want to save the data before exit?", "Warning",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                    hospital.Save();
                if (rez == DialogResult.Cancel)
                    e.Cancel = true;
            }

        }
    }
}
