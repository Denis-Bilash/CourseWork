﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{   
    public partial class RecepitionForm : Form
    {
        Hospital Hospital { get; }
        AutoCompleteStringCollection AutoCompletePatientsource = new AutoCompleteStringCollection();
        bool IsDirty = false;
        public delegate bool ExitHendler(bool dirty);
        public event ExitHendler ExitEvent;

        public RecepitionForm(Hospital sended, bool dirty)
        {
            InitializeComponent();
            Hospital = sended;
            IsDirty = dirty;
        }

        private void RecepitionForm_Load(object sender, EventArgs e)
        {
            hospitalBindingSource.DataSource = Hospital.Patients;
            //Для автозаполнения
            AutoCompliteCorrection();
        }
        private void RecepitionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ExitEvent?.Invoke(IsDirty);
        }

        public void AutoCompliteCorrection() 
        {
            AutoCompletePatientsource = new AutoCompleteStringCollection();
            for (int i = 0; i < Hospital.Patients.Count; i++)
                AutoCompletePatientsource.Add(Hospital.Patients[i].Name);

            textBoxSearch.AutoCompleteCustomSource = AutoCompletePatientsource;
            textBoxSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBoxSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void AddNewPatient_Click(object sender, EventArgs e)
        {
            NewPatient();
        }

        public void NewPatient() 
        {
            Patient temp = new Patient("", "", "", "", "");
            NewPatientForm NewPatientForm = new NewPatientForm(temp, Hospital);
            if (NewPatientForm.ShowDialog() == DialogResult.Yes)
            {
                Hospital.Patients.Add(temp);
                hospitalBindingSource.ResetBindings(false);
                IsDirty = true;
                AutoCompliteCorrection();
                int index = Hospital.FindPatientIndex(temp.Name);  // Ищем индекс добавленного пациента в массиве               
                Treatment(index);
            }
        }


        private void Button1_Click(object sender, EventArgs e)
        {
            Treatment(dataGridView1.SelectedRows[0].Index);  // Мы можем выбрать лишь одну строку в таблице
        }

        public void Treatment(int index) 
        {
            if (index != -1)
            {
                Patient patient = Hospital.Patients[index];     // Текущий пациент
                TreatmentInfo temp = new TreatmentInfo(0, "", "", "", null);
                TreatmentForm TreatmentForm = new TreatmentForm(temp,Hospital);
                if (TreatmentForm.ShowDialog() == DialogResult.Yes)
                {
                    patient.History.Add(temp);
                    IsDirty = true;
                }
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Information();
        }

        public void Information() 
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = Hospital.Patients[index];     // Текущий пациент
                PatientInfo PatientInfoForm = new PatientInfo(patient, Hospital);
                if (PatientInfoForm.ShowDialog() == DialogResult.Yes)
                {
                    hospitalBindingSource.ResetBindings(false);
                    IsDirty = true;
                    AutoCompliteCorrection();
                }
            }
            else 
            { MessageBox.Show("Please, select a patient", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                TreatmentInfo treatmentInfo;
                Patient patient = Hospital.Patients[index];     // Текущий пациент
                // Проверка на наличие истории
                if (patient.History.Count != 0)
                { treatmentInfo = patient.History[patient.History.Count - 1]; }
                else
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information",
                      MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (treatmentInfo.EndDate.Date >= DateTime.Now.Date)
                {
                    if (patient.TakeDate.Date != DateTime.Today)
                    {
                        TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(treatmentInfo, Hospital);
                        // Обновляем статус пользователя при успешном взятии
                        TreatmentInfoForm.Taken += () => { patient.ChangeTakeDade(DateTime.Now); IsDirty = true; };
                        TreatmentInfoForm.ShowDialog();                         
                        }
                    else 
                    {
                        MessageBox.Show("This patient already received it's medicines for today", "Warning",
                          MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else 
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            int index = Hospital.FindPatientIndex(textBoxSearch.Text);
            if (index != -1)
            {
                dataGridView1.Rows[index].Cells[0].Selected = true;
            }
        }

        private void OpenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiseaseClassification diseasetree;
            diseasetree = new DiseaseClassification();
            diseasetree.Load();

            DiseasesViewer DiseasesViewer = new DiseasesViewer(diseasetree);
            DiseasesViewer.ShowDialog();
        }

        private void OpenToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MedicineViewer MedicineViewer = new MedicineViewer(Hospital);
            MedicineViewer.ShowDialog();
        }

        private void ExitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsDirty)
            {
                var rez = MessageBox.Show("Do you want to save the data before exit?", "Warning",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                {
                    Hospital.Save();
                    Application.Exit();
                }
                if (rez == DialogResult.No)
                    Application.Exit();
            }
            
        }

        private void DataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Information();
        }

        private void InformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Information();
        }

        private void NewPatientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewPatient();
        }

        private void HelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Doctor menu help\n\n" +
               "This is the main window for Doctor." +
               "Here you can do several things:\n     " +
               "1. In \"File\" menu you can save and load the program's data. You also can close the program by clicking \"Exit\" button\n     " +
               "2. You can create a new patient profile by clicking at \"Patient -> New Patient\" button in the upper menu\n     " +
               "3. You can open the medicines base by clicking at \"Medicines\" button in the upper menu\n     " +
               "4.You can open the diseases window by clicking at \"Diseases\" button in the upper menu\n     " +
               "5.You can initialize a recepition prosedure, where you can create a treatment for a patient by clicking at \"Recepition\" button\n     " +
               "6.Ones a day you can give a patient some medicines from the medicine base, which are mentioned in it's current treatment\n     " +
               "For such prosedure, you need to chose a patient and clich at the \"Take medicines\" button.\n      " +
               "You will be alowed to take the medicines if any of them are available\n";

            DoctorHelpForm DoctorHelpForm = new DoctorHelpForm(message);
            DoctorHelpForm.ShowDialog();
        }
    }
}
