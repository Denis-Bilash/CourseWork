﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{   
    public partial class RecepitionForm : Form
    {
        Hospital hospital;
        AutoCompleteStringCollection AutoCompletePatientsource = new AutoCompleteStringCollection();
        bool IsDirty = false;
        public delegate bool ExitHendler(bool dirty);
        public event ExitHendler ExitEvent;

        public RecepitionForm(Hospital sended, bool dirty)
        {
            InitializeComponent();
            hospital = sended;
            IsDirty = dirty;
        }

        private void RecepitionForm_Load(object sender, EventArgs e)
        {
            hospitalBindingSource.DataSource = hospital.Patients;
            int count = dataGridView1.Columns.Count;
            dataGridView1.Columns[count-1].Visible = false;
            dataGridView1.Columns[count - 2].Visible = false;

            //Для автозаполнения
            AutoCompliteCorrection();
        }
        private void RecepitionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ExitEvent?.Invoke(IsDirty);
        }

        public void AutoCompliteCorrection() 
        {
            AutoCompletePatientsource = new AutoCompleteStringCollection();
            for (int i = 0; i < hospital.Patients.Count; i++)
                AutoCompletePatientsource.Add(hospital.Patients[i].Name);

            textBoxSearch.AutoCompleteCustomSource = AutoCompletePatientsource;
            textBoxSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBoxSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        private void AddNewPatient_Click(object sender, EventArgs e)
        {
            NewPatient();
        }

        public void NewPatient() 
        {
            Patient temp = new Patient("", "", "", "", "");
            NewPatientForm NewPatientForm = new NewPatientForm(temp, hospital);
            if (NewPatientForm.ShowDialog() == DialogResult.Yes)
            {
                hospital.Patients.Add(temp);
                hospitalBindingSource.ResetBindings(false);
                IsDirty = true;
                AutoCompliteCorrection();
                int index = hospital.Patients.FindIndex(x => x.Name == temp.Name);  // Ищем индекс добавленного пациента в массиве               
                Treatment(index);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Treatment(dataGridView1.SelectedRows[0].Index);  // Мы можем выбрать лишь одну строку в таблице
        }

        public void Treatment(int index) 
        {
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                TreatmentInfo temp = new TreatmentInfo(0, "", "", "", null);
                TreatmentForm TreatmentForm = new TreatmentForm(temp,hospital);
                if (TreatmentForm.ShowDialog() == DialogResult.Yes)
                {
                    patient.History.Add(temp);
                    IsDirty = true;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Information();
        }

        public void Information() 
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                Patient patient = hospital.Patients[index];     // Текущий пациент
                PatientInfo PatientInfoForm = new PatientInfo(patient, hospital);
                if (PatientInfoForm.ShowDialog() == DialogResult.Yes)
                {
                    hospitalBindingSource.ResetBindings(false);
                    IsDirty = true;
                    AutoCompliteCorrection();
                }
            }
            else 
            { MessageBox.Show("Please, select a patient", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.SelectedRows[0].Index;
            if (index != -1)
            {
                TreatmentInfo treatmentInfo;
                Patient patient = hospital.Patients[index];     // Текущий пациент
                // Проверка на наличие истории
                if (patient.History.Count != 0)
                { treatmentInfo = patient.History[patient.History.Count - 1]; }
                else
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information",
                      MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (treatmentInfo.EndDate.Date >= DateTime.Now.Date)
                {
                    if (patient.TakeDate.Date != DateTime.Today)
                    {
                        TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(treatmentInfo, hospital);
                        TreatmentInfoForm.Taken += () => patient.TakeDate = DateTime.Now;                    // Обновляем статус пользователя при успешном 
                        TreatmentInfoForm.ShowDialog();                                                      //взятии
                        IsDirty = true;
                    }
                    else 
                    {
                        MessageBox.Show("This patient already received it's medicines for today", "Warning",
                          MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else 
                {
                    MessageBox.Show("There is no active treatment for this patient", "Information", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            int index = hospital.Patients.FindIndex(x => x.Name == textBoxSearch.Text);
            if (index != -1)
            {
                dataGridView1.Rows[index].Cells[0].Selected = true;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DiseaseClassification diseasetree;
            diseasetree = new DiseaseClassification();
            diseasetree.Load();

            DiseasesViewer DiseasesViewer = new DiseasesViewer(diseasetree);
            DiseasesViewer.ShowDialog();
        }

        private void openToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MedicineViewer MedicineViewer = new MedicineViewer(hospital);
            MedicineViewer.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsDirty)
            {
                var rez = MessageBox.Show("Do you want to save the data before exit?", "Warning",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                {
                    hospital.Save();
                    Application.Exit();
                }
                if (rez == DialogResult.No)
                    Application.Exit();
            }
            
        }

        

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Information();
        }

        private void informationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Information();
        }

        private void newPatientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewPatient();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Doctor menu help\n\n" +
               "This is the main window for Doctor." +
               "Here you can do several things:\n     " +
               "1. In \"File\" menu you can save and load the program's data. You also can close the program by clicking \"Exit\" button\n     " +
               "2. You can create a new patient profile by clicking at \"Patient -> New Patient\" button in the upper menu\n     " +
               "3. You can open the medicines base by clicking at \"Medicines\" button in the upper menu\n     " +
               "4.You can open the diseases window by clicking at \"Diseases\" button in the upper menu\n     " +
               "5.You can initialize a recepition prosedure, where you can create a treatment for a patient by clicking at \"Recepition\" button\n     " +
               "6.Ones a day you can give a patient some medicines from the medicine base, which are mentioned in it's current treatment\n     " +
               "For such prosedure, you need to chose a patient and clich at the \"Take medicines\" button.\n      " +
               "You will be alowed to take the medicines if any of them are available\n";

            DoctorHelpForm DoctorHelpForm = new DoctorHelpForm(message);
            DoctorHelpForm.ShowDialog();
        }
    }
}
