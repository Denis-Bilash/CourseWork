﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DoctorAppForm : Form
    {
        Hospital hospital;
        DiseaseClassification diseasetree;
        bool IsDirty = false; 
        public DoctorAppForm()
        {
            InitializeComponent();
            hospital = new Hospital();
            //hospital.AddTestData(100);
            //hospital.Save();
            hospital.Load();

            diseasetree = new DiseaseClassification();
            diseasetree.AddTestData(100);
            diseasetree.Save();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RecepitionForm RecForm = new RecepitionForm(hospital, IsDirty);
            Visible = false;
            RecForm.ExitEvent += (x) => IsDirty = x;
            RecForm.ShowDialog();
            Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MedicineViewer MedicineViewer = new MedicineViewer(hospital);
            MedicineViewer.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DiseasesViewer DiseasesViewer = new DiseasesViewer(diseasetree);
            DiseasesViewer.ShowDialog();
        }
        private void DoctorAppForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (IsDirty)
            {
                var rez = MessageBox.Show("Do you want to save the data before exit?", "Warning",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                {
                    hospital.Save();
                }
                if (rez == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }

        private void DoctorAppForm_Load(object sender, EventArgs e)
        {

        }
    }
}
