﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DoctorAppForm : Form
    {
        Hospital Hospital { set; get; }
        DiseaseClassification Diseasetree { set; get; }
        bool IsDirty = false; 
        public DoctorAppForm()
        {
            InitializeComponent();
            Hospital = new Hospital();
            //Hospital.AddTestData(100);
            //Hospital.Save();
            Hospital.Load();

            Diseasetree = new DiseaseClassification();
            Diseasetree.AddTestData(100);
            Diseasetree.Save();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            RecepitionForm RecForm = new RecepitionForm(Hospital, IsDirty);
            Visible = false;
            RecForm.ExitEvent += (x) => IsDirty = x;
            RecForm.ShowDialog();
            Visible = true;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            MedicineViewer MedicineViewer = new MedicineViewer(Hospital);
            MedicineViewer.ShowDialog();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            DiseasesViewer DiseasesViewer = new DiseasesViewer(Diseasetree);
            DiseasesViewer.ShowDialog();
        }
        private void DoctorAppForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (IsDirty)
            {
                var rez = MessageBox.Show("Do you want to save the data before exit?", "Warning",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (rez == DialogResult.Yes)
                {
                    Hospital.Save();
                }
                if (rez == DialogResult.Cancel)
                    e.Cancel = true;
            }
        }
    }
}
