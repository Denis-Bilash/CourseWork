﻿using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DoctorAppForm : Form
    {
        Hospital hospital;
        public DoctorAppForm()
        {
            InitializeComponent();
            hospital = new Hospital();
            hospital.AddTestData(100);
            hospital.Save();
            //hospital.Load();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RecepitionForm RecForm = new RecepitionForm(hospital);
            RecForm.ShowDialog();
        }
    }
}
