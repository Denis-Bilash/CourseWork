﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class TreatmentInfoForm : Form
    {
        TreatmentInfo CurrTreatment { get; }
        Hospital Hospital { get; }

        [DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);
        public delegate void SuccessDele();
        public event SuccessDele Taken;
        public TreatmentInfoForm(TreatmentInfo sended)
        {
            InitializeComponent();
            CurrTreatment = sended;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        public TreatmentInfoForm(TreatmentInfo sended, Hospital sendedHospital)
        {
            InitializeComponent();
            CurrTreatment = sended;
            Hospital = sendedHospital;
            button1.Visible = true;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        private void TreatmentInfoForm_Load(object sender, EventArgs e)
        {
            labelStartDate.Text = CurrTreatment.StartDate.ToString();
            labelEndDate.Text = CurrTreatment.EndDate.ToString();
            textBoxComplainments.Text = CurrTreatment.Complainments;
            textBoxDiagnose.Text = CurrTreatment.Diagnosis;
            textBoxProcedures.Text = CurrTreatment.Procedures;
            dataGridView1.ClearSelection();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            List<Medicine> toChange = new List<Medicine>();
            List<int> toChangeValue = new List<int>();
            List<Medicine> notFound = new List<Medicine>();
            string message = "";
            List<string> replacements = new List<string>();
            List<int> repValue = new List<int>();

            for (int i = 0; i < CurrTreatment.Treatments.Count; i++) 
            {
                int medicineAmount = CurrTreatment.Treatments[i].Amount; // Индикатор количества лекарства на складе
                int medicineIndex = SearchMedicine(CurrTreatment.Treatments[i].Name, ref medicineAmount);
                // Если medicineAmount > 0 лекарств на складе меньше чем нужно взять

                // В случае с лекарствами 1-->2, 2-->3 не значит 1-->3, то есть транзитивность не выполняеться
                // Поэтому будем искать заменители только из перечня в начальном медикаменте (дальше по цепочке не пойдём)
                if (medicineIndex == -1 || CurrTreatment.Treatments[i].Amount - medicineAmount == 0)
                { // ПОВТОРИТЬ ДЛЯ ВСЕХ ЗАМЕНИТЕЛЕЙ 
                    bool found = false;
                    for (int j = 0; j < CurrTreatment.Treatments[i].Replacements.Count; j++)
                    {
                        medicineAmount = CurrTreatment.Treatments[i].Amount;
                        int replaceIndex = SearchMedicine(CurrTreatment.Treatments[i].Replacements[j], ref medicineAmount);
                        if (replaceIndex != -1)
                        {
                            if (replacements.IndexOf(Hospital.Medicines[replaceIndex].Name) == -1)  // При первом вхождении добавляем
                            {
                                replacements.Add(Hospital.Medicines[replaceIndex].Name);
                                if (medicineAmount < 0)
                                    repValue.Add(CurrTreatment.Treatments[i].Amount);
                                else
                                    repValue.Add(-1);  // Забрали последние со склада
                            }
                            else // уже меняли заминитель
                            {
                                int index = replacements.IndexOf(Hospital.Medicines[replaceIndex].Name);
                                if (repValue[index] == -1)  // Больше нету
                                    continue;
                                else
                                {
                                    medicineAmount += repValue[index]; // учли уже взятое количиство
                                    if (medicineAmount > 0)  // Добираем последнее
                                        repValue[index] = -1;
                                    else // Осталось больше чем взяли сумарно
                                    {
                                        repValue[index] += CurrTreatment.Treatments[i].Amount;
                                    }
                                }
                            }

                            if (medicineAmount <= 0)
                            {
                                message += $"Instead of {CurrTreatment.Treatments[i].Name} " +
                                    $"you can take {CurrTreatment.Treatments[i].Replacements[j]}.\n";
                                toChange.Add(Hospital.Medicines[replaceIndex]);
                                toChangeValue.Add(CurrTreatment.Treatments[i].Amount);
                                found = true;
                                break;
                            }
                            else if(medicineAmount < CurrTreatment.Treatments[i].Amount)// Берем только часть от нужного количества заменителя 
                            {// Хотя бы одна единица препарата доступна на складе
                                message += $"Instead of {CurrTreatment.Treatments[i].Name}" +
                                    $" you can take {CurrTreatment.Treatments[i].Replacements[j]}.\n" +
                                    $"Only {CurrTreatment.Treatments[i].Amount - medicineAmount} " +
                                    $"{CurrTreatment.Treatments[i].Unit} of it is available\n";

                                toChange.Add(Hospital.Medicines[replaceIndex]);
                                toChangeValue.Add(CurrTreatment.Treatments[i].Amount - medicineAmount);
                                found = true;
                                break;
                            }//Здесь мы не провиряем остальные заменители, даже если их больше. качество >> количество
                        }                        
                    }
                    if (!found) // Нет ни лекарства ни заменителей
                    {
                        message += $"Medicine {CurrTreatment.Treatments[i].Name} is not available\n";
                        notFound.Add(CurrTreatment.Treatments[i]);
                    }
                }
                else if (medicineAmount <= 0)
                {
                    toChange.Add(Hospital.Medicines[medicineIndex]);
                    toChangeValue.Add(CurrTreatment.Treatments[i].Amount);
                }
                else // Берем часть от нужного количества первоначального лекарства
                {
                    message += $"Only {CurrTreatment.Treatments[i].Amount - medicineAmount} {CurrTreatment.Treatments[i].Unit} of " +
                        $"{CurrTreatment.Treatments[i].Name} is available\n";
                    toChange.Add(Hospital.Medicines[medicineIndex]);
                    toChangeValue.Add(CurrTreatment.Treatments[i].Amount - medicineAmount);
                }
            }

            // Выводим сообщение пользователю, в случае согласия берем лекарства.
            if (toChange.Count == 0)
            {
                MessageBox.Show("None of treatments is available", "Information",MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Close();
                return;
            }
            if (message != "") 
            {
                var rez = MessageBox.Show(message + "Are you sure you want to continue?", "Be careful!", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);
                if (rez == DialogResult.No)
                    return;
            }
            // забираем лекарства, отнимая от их количества в базе, количество что мы взяли
            message = "You are allowed to take:\n";
            for (int g = 0; g < toChange.Count; g++) 
            {
                toChange[g].Amount -= toChangeValue[g];
                message += $"{toChangeValue[g]} {toChange[g].Unit} of {toChange[g].Name}\n";
            }
            MessageBox.Show(message, "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Taken?.Invoke();
            Close();
        }

        public int SearchMedicine(string currentName, ref int currentAmount) 
        {
            int index = Hospital.FindMedicieIndex(currentName);
            if ( index != -1) 
            {
                currentAmount -= Hospital.Medicines[index].Amount;
                return index;
            }
            return -1;
        }

        private void TextBoxDiagnose_MouseClick(object sender, MouseEventArgs e)
        {
            var Box = sender as TextBox;
            HideCaret(Box.Handle);
        }
    }
}
