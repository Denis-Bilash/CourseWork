﻿using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class TreatmentInfoForm : Form
    {
        TreatmentInfo currTreatment;
        Hospital hospital;
        public TreatmentInfoForm(TreatmentInfo sended)
        {
            InitializeComponent();
            currTreatment = sended;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        public TreatmentInfoForm(TreatmentInfo sended, Hospital sendedHospital)
        {
            InitializeComponent();
            currTreatment = sended;
            hospital = sendedHospital;
            button1.Visible = true;
            medicineBindingSource.DataSource = sended.Treatments;
        }

        private void TreatmentInfoForm_Load(object sender, EventArgs e)
        {
            labelStartDate.Text = currTreatment.StartDate.ToString();
            labelEndDate.Text = currTreatment.EndDate.ToString();
            textBoxComplainments.Text = currTreatment.Complainments;
            textBoxDiagnose.Text = currTreatment.Diagnosis;
            textBoxProcedures.Text = currTreatment.Procedures;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ЗАМЕНИТЬ ТИП ЛЕЧЕНИЯ СО СТРОКИ НА ПРЕКАРАТ
            List<Medicine> toChange = new List<Medicine>();
            List<int> toChangeValue = new List<int>();
            List<Medicine> notFound = new List<Medicine>();
            string message = "";

            for (int i = 0; i < currTreatment.Treatments.Count; i++) 
            {
                int medicineAmount = currTreatment.Treatments[i].Amount; // Индикатор количества лекарства на складе
                int medicineIndex = SearchMedicine(currTreatment.Treatments[i].Name, ref medicineAmount);
                // Если medicineAmount > 0 лекарств на складе меньше чем нужно взять

                // В случае с лекарствами 1-->2, 2-->3 не значит 1-->3, то есть транзитивность не выполняеться
                // Поэтому будем искать заменители только из перечня в начальном медикаменте (дальше по цепочке не пойдём)
                if (medicineIndex == -1 || currTreatment.Treatments[i].Amount - medicineAmount == 0)
                { // ПОВТОРИТЬ ДЛЯ ВСЕХ ЗАМЕНИТЕЛЕЙ 
                    for (int j = 0; j < currTreatment.Treatments[i].Replacements.Count; j++)
                    {
                        int replaceIndex = SearchMedicine(currTreatment.Treatments[i].Replacements[j], ref medicineAmount);
                        if (replaceIndex != -1)
                        {
                            if (medicineAmount <= 0)
                            {
                                message += $"Instead of {currTreatment.Treatments[i].Name} " +
                                    $"you can take {currTreatment.Treatments[i].Replacements[j]}.\n";
                                toChange.Add(hospital.Medicines[replaceIndex]);
                                toChangeValue.Add(currTreatment.Treatments[i].Amount);
                                break;
                            }
                            else if(medicineAmount != currTreatment.Treatments[i].Amount)// Берем только часть от нужного количества заменителя 
                            {// Хотя бы одна единица препарата доступна на складе
                                message += $"Instead of {currTreatment.Treatments[i].Name}" +
                                    $" you can take {currTreatment.Treatments[i].Replacements[j]}.\n" +
                                    $"Only {currTreatment.Treatments[i].Amount - medicineAmount} " +
                                    $"{currTreatment.Treatments[i].Unit} of it is available\n";

                                toChange.Add(hospital.Medicines[replaceIndex]);
                                toChangeValue.Add(currTreatment.Treatments[i].Amount - medicineAmount);
                                break;
                            }//Здесь мы не провиряем остальные заменители, даже если их больше. качество >> количество
                        }
                        else if(j == currTreatment.Treatments[i].Replacements.Count -1) // Нет ни лекарства ни заменителей
                        {
                            message += $"Medicine {currTreatment.Treatments[i].Name} is not available\n";
                            notFound.Add(currTreatment.Treatments[i]);
                        }
                    }
                }
                else if (medicineAmount <= 0)
                {
                    toChange.Add(hospital.Medicines[medicineIndex]);
                    toChangeValue.Add(currTreatment.Treatments[i].Amount);
                }
                else // Берем часть от нужного количества первоначального лекарства
                {
                    message += $"Only {currTreatment.Treatments[i].Amount - medicineAmount} {currTreatment.Treatments[i].Unit} of " +
                        $"{currTreatment.Treatments[i].Name} is available\n";
                    toChange.Add(hospital.Medicines[medicineIndex]);
                    toChangeValue.Add(currTreatment.Treatments[i].Amount - medicineAmount);
                }
            }

            // Выводим сообщение пользователю, в случае согласия берем лекарства.
            if (toChange.Count == 0)
            {
                MessageBox.Show("None of treatments is available", "Information",MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                this.Close();
                return;
            }
            if (message != "") 
            {
                var rez = MessageBox.Show(message + "Are you sure you want to continue?", "Be careful!", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information);
                if (rez == DialogResult.No)
                    return;
            }
            // забираем лекарства, отнимая от их количества в базе, количество что мы взяли
            message = "You are allowed to take:\n";
            for (int g = 0; g < toChange.Count; g++) 
            {
                toChange[g].Amount -= toChangeValue[g];
                message += $"{toChangeValue[g]} {toChange[g].Unit} of {toChange[g].Name}\n";
            }
            MessageBox.Show(message, "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
        }

        public int SearchMedicine(string currentName, ref int currentAmount) 
        {
            for (int j = 0; j < hospital.Medicines.Count; j++)
                if (currentName == hospital.Medicines[j].Name)
                {
                    currentAmount -= hospital.Medicines[j].Amount;
                    return j;
                }
            return -1;
        }
    }
}
