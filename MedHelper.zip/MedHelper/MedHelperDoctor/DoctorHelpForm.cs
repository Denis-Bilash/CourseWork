﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class DoctorHelpForm : Form
    {
        public DoctorHelpForm(string message)
        {
            InitializeComponent();
            label1.Text = message;
        }

        private void DoctorHelpForm_Load(object sender, EventArgs e)
        {
            this.Width = label1.Width + 100;
            this.Height = label1.Height + button1.Height + 150;
            var size = new System.Drawing.Size(this.Width, this.Height);
            this.MinimumSize = size;
            this.MaximumSize = size;
        }
    }
}
