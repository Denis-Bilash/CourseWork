﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class MedInfo : Form
    {
        Medicine Medicine { get; }
        [DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);
        public MedInfo(Medicine sended)
        {
            InitializeComponent();
            Medicine = sended;
            listBox1.DataSource = sended.Replacements;
        }

        private void MedicineInfo_Load(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            textBoxAmount.Text = Convert.ToString(Medicine.Amount);
            textBoxDescription.Text = Medicine.Description;
            textBoxName.Text = Medicine.Name;
            textBoxUnit.Text = Medicine.Unit;
            textBoxId.Text = Convert.ToString(Medicine.Id);
            pictureBox1.Image = Medicine.Image;     
        }

        private void TextBoxName_MouseClick(object sender, MouseEventArgs e)
        {
            var Box = sender as TextBox;
            HideCaret(Box.Handle);
        }

        private void TextBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            SystemSounds.Exclamation.Play();
        }
    }
}
