﻿using MedHelperLibraryNew.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class MedInfo : Form
    {
        Medicine medicine;
        [DllImport("user32.dll")]
        static extern bool HideCaret(IntPtr hWnd);
        public MedInfo(Medicine sended)
        {
            InitializeComponent();
            medicine = sended;
            listBox1.DataSource = sended.Replacements;
        }

        private void MedicineInfo_Load(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = -1;
            textBoxAmount.Text = Convert.ToString(medicine.Amount);
            textBoxDescription.Text = medicine.Description;
            textBoxName.Text = medicine.Name;
            textBoxUnit.Text = medicine.Unit;
            labelId.Text = Convert.ToString(medicine.Id);
            pictureBox1.Image = medicine.Image;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxName_MouseClick(object sender, MouseEventArgs e)
        {
            var Box = sender as TextBox;
            HideCaret(Box.Handle);
        }
    }
}
