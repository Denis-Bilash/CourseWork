﻿using MedHelperLibraryNew.Models;
using System;
using System.Media;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class PatientInfo : Form
    {
        Patient currPatient;
        Hospital hospital;
        public PatientInfo(Patient sended, Hospital secondsended)
        {
            InitializeComponent();
            currPatient = sended;
            hospital = secondsended;
        }

        private void PatientInfo_Load(object sender, EventArgs e)
        {
            textBoxName.Text = currPatient.Name;
            textBoxAdress.Text = currPatient.Adress;
            maskedTextBoxBirthdate.Text = currPatient.Birthdate;
            comboBoxSex.Text = currPatient.Sex;
            textBoxDescription.Text = currPatient.Description;
            treatmentInfoBindingSource.DataSource = currPatient.History;

        }

        private void listBoxHistory_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = listBoxHistory.IndexFromPoint(e.Location);  // Проверяем, если щелчок произошел на элементе 
            if (index != -1) 
            {
                TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(currPatient.History[index]);
                TreatmentInfoForm.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Валидация
            if (textBoxName.Text == "")
            { MessageBox.Show("Invalid name", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (textBoxAdress.Text == "")
            { MessageBox.Show("Invalid unit ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }
            if (!maskedTextBoxBirthdate.MaskCompleted)
            { MessageBox.Show("Invalid birthdate ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning); DialogResult = DialogResult.None; return; }

            foreach (Patient patient in hospital.Patients)
            {
                if (patient.Name == textBoxName.Text && hospital.Patients.IndexOf(patient) != hospital.Patients.IndexOf(currPatient))
                {
                    MessageBox.Show("Patient with such a name is already exists", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.None;
                    return;
                }
            }

            // Сохраняем данные (без привязки)
            currPatient.Name = textBoxName.Text;
            currPatient.Description = textBoxDescription.Text;
            currPatient.Adress = textBoxAdress.Text;
            currPatient.Sex = comboBoxSex.Text;
            currPatient.Birthdate = maskedTextBoxBirthdate.Text;
        }

        private void textBoxName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }

        }

        private void textBoxAdress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetterOrDigit(e.KeyChar) && !Char.IsControl(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',' && e.KeyChar != '-')
            {
                e.Handled = true;
                SystemSounds.Exclamation.Play();
            }
        }
    }
}
