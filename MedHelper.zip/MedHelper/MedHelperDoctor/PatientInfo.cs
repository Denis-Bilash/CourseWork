﻿using MedHelperLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedHelperDoctor
{
    public partial class PatientInfo : Form
    {
        Patient currPatient;
        public PatientInfo(Patient sended)
        {
            InitializeComponent();
            currPatient = sended;
        }

        private void PatientInfo_Load(object sender, EventArgs e)
        {
            labelName.Text = currPatient.Name;
            labelAdress.Text = currPatient.Adress;
            labelBirthDate.Text = currPatient.Birthdate;
            labelSex.Text = currPatient.Sex;
            textBoxDescription.Text = currPatient.Description;
            treatmentInfoBindingSource.DataSource = currPatient.History;

        }

        private void listBoxHistory_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int index = listBoxHistory.IndexFromPoint(e.Location);  // Проверяем, если щелчок произошел на элементе 
            if (index != -1) 
            {
                TreatmentInfoForm TreatmentInfoForm = new TreatmentInfoForm(currPatient.History[index]);
                TreatmentInfoForm.ShowDialog();
            }
        }
    }
}
